AXEAP: Argonne X-Ray Emission Analysis Package

pyAXEAP-GUI1 is the python interface version of AXEAP.

On Windows, you can either use the *.exe version or the *.py version. They are identical.
If using the *.py version, simply run "mainWindow.py" in the "src" directory.

If you notice there are no icons on the windows, ensure the "icons" folder is within the src folder.
Also ensure that "mainWindow.py" was run from within the "src" folder.

You are able to run the XES Window and RXES Window by running their respective python files.


WINDOWS INSTALLATION:

If using the Windows installer, simply extract the installer .exe and run it.
You can also download the portable version and run it without installing it.


PYTHON INSTALLATION:

First, ensure you have python and pip installed.
You can check that python is installed by typing "python --version".
You can check that pip is installed by typing "python -m pip --version" or "pip --version".
If you need help installing python or pip, speak to your IT department.

Open a command line in the "AXEAP-pkg" folder.
	Windows: right click the window and click "Open In Terminal".

Next, run the command "python -m pip install -r requirements.txt" in the same directory.
This will install the AXEAP package as well as all other required python packages.

REQUIRED PACKAGES:
h5py~=3.11.0
matplotlib~=3.8.4
numpy~=1.26.4
openpyxl~=3.1.5
PyQt6~=6.7.0
PyQt6_sip~=13.6.0
pyqtgraph~=0.13.7
scikit_learn~=1.4.2
scipy~=1.13.0

NOTE: ~= means "compatible with".
If you already have a different version that is compatible, pip will skip the install.