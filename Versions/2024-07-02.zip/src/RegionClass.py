from RectangleClass import Rectangle


class Region(Rectangle):
    pass
