# :author: Alexander Berno

import axeap.core as core
from axeap.core.conventions import X, Y
import sys
import matplotlib
import matplotlib.patches
from functions import *
import multiprocessing
from GetPoints import GetPoints
from axeap.core.roi import HROI
from math import log
import pathlib

multiprocessing.freeze_support()

matplotlib.use("QTAgg")

from PyQt6 import QtCore, QtWidgets, QtGui

AlignFlag = QtCore.Qt.AlignmentFlag

from PyQt6.QtWidgets import QCheckBox
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg,
    NavigationToolbar2QT as NavigationToolbar,
)
from matplotlib.figure import Figure


# Creates a loading bar window for any loading processes
class LoadingBarWindow(QtWidgets.QProgressDialog):
    def __init__(self, message: str, num: int, *args, **kwargs):
        super(LoadingBarWindow, self).__init__(*args, **kwargs)

        self.setLabelText(message)
        self.setAutoClose(True)
        self.canceled.connect(self.cancel)
        self.setValue(0)
        self.setMaximum(num)

        self.show()

    def add(self):
        self.setValue(self.value() + 1)

    def cancel(self):
        pass


class ApproxWindow(QtWidgets.QDialog):
    def __init__(self, *args, **kwargs):
        super(ApproxWindow, self).__init__(*args, **kwargs)
        self.setWindowTitle("Number of Crystals")
        self.setMinimumSize(240, 120)
        buttons = (
            QtWidgets.QDialogButtonBox.StandardButton.Ok
            | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        label = QtWidgets.QLabel("Number of Crystals in Experiment:")
        self.spinbox = QtWidgets.QSpinBox()
        self.spinbox.setMaximum(100)
        self.spinbox.setMinimumSize(64, 20)
        self.spinbox.setValue(8)
        self.value = 8

        button_box = QtWidgets.QDialogButtonBox(buttons)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        layout = QtWidgets.QGridLayout()
        layout.addWidget(label, 0, 0, alignment=AlignFlag.AlignRight)
        layout.addWidget(self.spinbox, 0, 1, alignment=AlignFlag.AlignLeft)
        layout.addWidget(button_box, 1, 0, 2, 1, alignment=AlignFlag.AlignRight)

        self.setLayout(layout)
        self.show()

    def accept(self):
        super().accept()
        self.value = self.spinbox.value()

    def reject(self):
        super().reject()
        self.value = None

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()


# Creates a window to display errors/problems for users
class ErrorWindow(QtWidgets.QDialog):

    def __init__(self, error: str = "None", *args, **kwargs):
        super(ErrorWindow, self).__init__(*args, **kwargs)

        self.setWindowTitle("Error")
        self.setMinimumHeight(120)
        # error syntax is "[attempted calculation/execution] [reason for not working]"
        if error == "None":
            return
        elif error == "emapCalib":
            labeltext = "You must select calibration data to calculate the energy map."
        elif error == "XESemap":
            labeltext = "You must calculate an energy map to calculate XES spectra."
        elif error == "minmaxcuts":
            labeltext = "Minimum cuts must be lower than or equal to maximum cuts."
        else:
            labeltext = "Unknown Error Occurred."

        button = QtWidgets.QDialogButtonBox.StandardButton.Ok
        label = QtWidgets.QLabel(text=labeltext)
        button_box = QtWidgets.QDialogButtonBox(button)
        button_box.accepted.connect(self.accept)

        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(label)
        layout.addWidget(button_box, alignment=AlignFlag.AlignCenter)

        self.setLayout(layout)
        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()


class MplCanvas(FigureCanvasQTAgg):

    def __init__(
        self,
        parent,
        width=5,
        height=4,
        dpi=100,
    ):
        fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(fig)


class MainWindow(QtWidgets.QMainWindow):
    """Main Window for application. Allows the viewing of data."""

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.sel_x1 = None
        self.sel_y1 = None
        self.sel_x2 = None
        self.sel_y2 = None
        self.sel_ax = None
        self.sel_rect = [None, None, None, None]
        self.rects = []
        self.drawn_calib = False
        self.left_button = False
        self.ax = None
        self.childWindow = None

        self.setWindowTitle("pyAXEAP1")

        # Canvas and Toolbar for main window
        self.sc = MplCanvas(self, width=5, height=4, dpi=100)
        self.sc.mpl_connect("button_press_event", self.buttonPress)
        self.sc.mpl_connect("button_release_event", self.buttonRelease)
        self.sc.mpl_connect("motion_notify_event", self.pan)
        toolbar = NavigationToolbar(self.sc, self)

        # button for opening calibration data
        cali_button = QtWidgets.QPushButton("Calibration Data...")
        cali_button.clicked.connect(self.openPath)

        # button for opening XES menu
        xes_button = QtWidgets.QPushButton("XES")
        xes_button.clicked.connect(self.runXES)

        # button for loading an existing energy map
        emap_load_button = QtWidgets.QPushButton("Load Energy Map...")
        emap_load_button.clicked.connect(self.loadEmap)

        # energy map buttons
        emap_area = QtWidgets.QScrollArea()
        emap_widget = QtWidgets.QWidget()
        emap_grid = QtWidgets.QGridLayout(emap_widget)
        mincuts_label = QtWidgets.QLabel("Minimum Cuts")
        self.mincuts = QtWidgets.QSpinBox()
        self.mincuts.setMinimumSize(128, 20)
        self.mincuts.setMaximum(10000000)
        self.mincuts.setValue(3)
        maxcuts_label = QtWidgets.QLabel("Maximum cuts")
        self.maxcuts = QtWidgets.QSpinBox()
        self.maxcuts.setMinimumSize(128, 20)
        self.maxcuts.setMaximum(10000000)
        self.maxcuts.setValue(10000)
        self.approx_rois = QtWidgets.QPushButton("Calculate ROIs")
        self.approx_rois.setDisabled(True)
        self.approx_rois.clicked.connect(self.approxROIs)
        self.emap_select_button = QtWidgets.QPushButton("Edit ROIs")
        self.emap_select_button.setStyleSheet("background-color: gray")
        self.emap_select_button.setDisabled(True)
        self.emap_select_button.clicked.connect(self.selectEmap)
        self.emap_select_button.activated = False
        self.emap_calc_button = QtWidgets.QPushButton("Caibrate")
        self.emap_calc_button.clicked.connect(self.calcEmap)
        self.emap_calc_button.setDisabled(True)
        self.emap_save_button = QtWidgets.QPushButton("Save Energy Map As...")
        self.emap_save_button.clicked.connect(self.saveEmap)
        self.emap_save_button.setDisabled(True)

        # energy map layout connections
        emap_grid.addWidget(mincuts_label, 0, 0)
        emap_grid.addWidget(self.mincuts, 0, 1)
        emap_grid.addWidget(maxcuts_label, 1, 0)
        emap_grid.addWidget(self.maxcuts, 1, 1)
        emap_grid.addWidget(self.approx_rois, 2, 0)
        emap_grid.addWidget(self.emap_select_button, 2, 1)
        emap_grid.addWidget(self.emap_calc_button, 3, 0)
        emap_grid.addWidget(self.emap_save_button, 4, 0)
        emap_area.setWidget(emap_widget)

        # main "widget"; basically everything that is within the main window
        mwidget = QtWidgets.QWidget()

        # connects everything to the window with grid organization
        self.mlayout = QtWidgets.QGridLayout(mwidget)
        self.mlayout.addWidget(cali_button, 0, 0, AlignFlag.AlignLeading)
        self.mlayout.addWidget(emap_load_button, 0, 1, AlignFlag.AlignLeft)
        self.mlayout.addWidget(xes_button, 1, 0, AlignFlag.AlignLeft)
        self.mlayout.addWidget(
            emap_area, 2, 0, 1, 2, AlignFlag.AlignLeft | AlignFlag.AlignTop
        )
        self.mlayout.addWidget(toolbar, 1, 2, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.sc, 2, 2, AlignFlag.AlignCenter)
        self.mlayout.setColumnMinimumWidth(2, 500)

        self.setCentralWidget(mwidget)

        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()

    def openPath(self):
        self.calibfiledir = QtWidgets.QFileDialog.getExistingDirectory()

        if self.calibfiledir is not None and self.calibfiledir != "":
            self.calibscans = loadCalib(self.calibfiledir)
            self.getCalibSpectra()

    def getCalibSpectra(self):
        minc = self.mincuts.value()
        maxc = self.maxcuts.value()
        if minc > maxc:
            self.error = ErrorWindow("minmaxcuts")
        self.rects = []
        self.LoadWindow = LoadingBarWindow(
            "Loading calibration data...", len(self.calibscans)
        )
        self.points = []
        self.thread = QtCore.QThread()
        self.worker = GetPoints(scans=self.calibscans, cuts=(minc, maxc))
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.finished.connect(self.drawCalibSpectra)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.progress.connect(self.addPoints)

        self.thread.start()

    def addPoints(self, n):
        self.points.append(n)
        self.LoadWindow.add()

    def drawCalibSpectra(self):
        if self.ax is not None:
            self.ax.remove()
        self.ax = self.sc.figure.add_subplot()
        m = 0

        for i in self.points:
            if m < max(i[2]):
                m = max(i[2])
        for i in self.points:
            alpha = [
                (((0.1 - (0.5 / log(m / 3)) * log(3)) + (0.5 / log(m / 3)) * log(j)))
                for j in i[2]
            ]
            self.ax.scatter(i[0], i[1], s=0.1, color="red", alpha=alpha)

        self.sc.draw()
        self.drawn_calib = True
        self.approx_rois.setDisabled(False)
        self.emap_select_button.setDisabled(False)
        self.emap_calc_button.setDisabled(False)

    def selectEmap(self):
        if self.emap_select_button.activated:
            self.emap_select_button.setText("Select ROIs")
            self.emap_select_button.setStyleSheet("background-color: gray")
            self.emap_select_button.activated = False
            self.approx_rois.setDisabled(False)
            self.emap_calc_button.setDisabled(False)
        else:
            self.emap_select_button.setText("Finish Selection")
            self.emap_select_button.setStyleSheet("background-color: green")
            self.emap_select_button.activated = True
            self.approx_rois.setDisabled(True)
            self.emap_calc_button.setDisabled(True)

    def buttonPress(self, event):
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if (
            modifiers == QtCore.Qt.KeyboardModifier.ControlModifier
            or not self.drawn_calib
        ):
            return
        # begins drawing a rectangle over the grid
        if event.button == 1:
            if not self.emap_select_button.activated:
                return
            self.sel_ax = event.inaxes
            x = event.xdata
            y = event.ydata
            for j in self.rects:
                i = j[1]
                if i[0] - 5 < x < i[0] + 5 and i[2] - 5 < y < i[2] + 5:
                    self.sel_x2 = i[0]
                    self.sel_y2 = i[2]
                    self.sel_x1 = i[1]
                    self.sel_y1 = i[3]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                elif i[1] - 5 < x < i[1] + 5 and i[2] - 5 < y < i[2] + 5:
                    self.sel_x2 = i[1]
                    self.sel_y2 = i[2]
                    self.sel_x1 = i[0]
                    self.sel_y1 = i[3]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                elif i[0] - 5 < x < i[0] + 5 and i[3] - 5 < y < i[3] + 5:
                    self.sel_x2 = i[0]
                    self.sel_y2 = i[3]
                    self.sel_x1 = i[1]
                    self.sel_y1 = i[2]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                elif i[1] - 5 < x < i[1] + 5 and i[3] - 5 < y < i[3] + 5:
                    self.sel_x2 = i[1]
                    self.sel_y2 = i[3]
                    self.sel_x1 = i[0]
                    self.sel_y1 = i[2]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                else:
                    continue

            self.left_button = True
            if self.sel_x1 is None and self.sel_y1 is None:
                self.left_button = False
            self.sc.draw()
        # deletes a rectangle if the RMB is pressed over a rectangle
        elif event.button == 3:
            if not self.emap_select_button.activated:
                return
            for i in self.rects:
                # self.rects[i][1] has all xy values as (x1,x2,y1,y2)
                xy = i[1]
                x1 = min(xy[0], xy[1])
                x2 = max(xy[0], xy[1])
                y1 = min(xy[2], xy[3])
                y2 = max(xy[2], xy[3])
                x = event.xdata
                y = event.ydata
                if x1 < x < x2 and y1 < y < y2:
                    for j in i[0]:
                        j.remove()
                    self.rects.remove(i)
                    break
            self.sc.draw_idle()

    def buttonRelease(self, event):
        if not self.drawn_calib:
            return
        if event.button == 1:
            if not self.emap_select_button.activated or not self.left_button:
                return
            self.left_button = False

            if not (self.sel_x1 * 0.9 < self.sel_x2 < self.sel_x1 * 1.1) or not (
                self.sel_y1 * 0.9 < self.sel_y2 < self.sel_y1 * 1.1
            ):
                rect = [None, None, None, None]
                # lines drawn x1y1 to x2y1, x2y1 to x2y2, x2y2 to x1y2, x1y2 to x1y1
                (rect[0],) = self.sel_ax.plot(
                    [self.sel_x1, self.sel_x2],
                    [self.sel_y1, self.sel_y1],
                    clip_on=False,
                    color="red",
                )
                (rect[1],) = self.sel_ax.plot(
                    [self.sel_x2, self.sel_x2],
                    [self.sel_y1, self.sel_y2],
                    clip_on=False,
                    color="red",
                )
                (rect[2],) = self.sel_ax.plot(
                    [self.sel_x2, self.sel_x1],
                    [self.sel_y2, self.sel_y2],
                    clip_on=False,
                    color="red",
                )
                (rect[3],) = self.sel_ax.plot(
                    [self.sel_x1, self.sel_x1],
                    [self.sel_y2, self.sel_y1],
                    clip_on=False,
                    color="red",
                )
                rect = [
                    rect.copy(),
                    (self.sel_x1, self.sel_x2, self.sel_y1, self.sel_y2),
                ]
                self.rects.append(rect)

            try:
                if self.sel_rect[0] is not None:
                    self.sel_rect[0].remove()
                if self.sel_rect[1] is not None:
                    self.sel_rect[1].remove()
                if self.sel_rect[2] is not None:
                    self.sel_rect[2].remove()
                if self.sel_rect[3] is not None:
                    self.sel_rect[3].remove()
            finally:
                self.sel_rect = [None, None, None, None]
            self.sel_x1 = None
            self.sel_y1 = None
            self.sel_ax = None
            self.sc.draw()

    def pan(self, event):
        if not self.drawn_calib:
            return
        if not self.emap_select_button.activated:
            return
        if self.sel_x1 is not None and self.sel_y1 is not None:
            x = event.xdata
            y = event.ydata
            if x is None or y is None:
                return
            self.sel_x2 = x
            self.sel_y2 = y
            try:
                if self.sel_rect[0] is not None:
                    self.sel_rect[0].remove()
                if self.sel_rect[1] is not None:
                    self.sel_rect[1].remove()
                if self.sel_rect[2] is not None:
                    self.sel_rect[2].remove()
                if self.sel_rect[3] is not None:
                    self.sel_rect[3].remove()
            finally:
                self.sel_rect = [None, None, None, None]
            (self.sel_rect[0],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x2],
                [self.sel_y2, self.sel_y2],
                "k",
                clip_on=False,
            )
            (self.sel_rect[1],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x2],
                [self.sel_y1, self.sel_y1],
                "k",
                clip_on=False,
            )
            (self.sel_rect[2],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x1],
                [self.sel_y1, self.sel_y2],
                "k",
                clip_on=False,
            )
            (self.sel_rect[3],) = self.sel_ax.plot(
                [self.sel_x2, self.sel_x2],
                [self.sel_y1, self.sel_y2],
                "k",
                clip_on=False,
            )
            self.sc.draw_idle()

    def approxROIs(self):
        self.ApproxWindow = ApproxWindow(self)
        self.ApproxWindow.finished.connect(self.doApproxROIs)

    def doApproxROIs(self):
        if self.ApproxWindow.value is None:
            return
        numcrystals = self.ApproxWindow.value
        s = self.calibscans.items[0]
        minwidth = s.dims[X] / numcrystals / 3
        hrois = core.calcHROIs(
            s.mod(cuts=(self.mincuts.value(), self.maxcuts.value())),
            min_width=minwidth,
            group_buffer=10,
        )
        hrois = list((h.lo, h.hi) for h in hrois)
        while len(hrois) < numcrystals:
            maxhroi = 0
            for i, h in enumerate(hrois):
                if maxhroi < abs(h[1] - h[0]):
                    maxhroi = abs(h[1] - h[0])
                    maxh = (i, h)
            h = maxh[1]
            hrois.remove(h)
            hrois.insert(maxh[0], (h[0], int((h[0] + h[1]) / 2) - 5))
            hrois.insert(maxh[0] + 1, (int((h[0] + h[1]) / 2) + 5, h[1]))

        vrois = []
        for h in hrois:
            ymin = 100000
            ymax = 0
            for i in self.points:
                n = tuple(
                    (i[1][val], u)
                    for val, u in enumerate(i[2])
                    if h[0] < i[0][val] < h[1]
                )
                ys = tuple(
                    y[0] for y in n if y[0] > 0 and y[0] < s.dims[Y] and y[1] > 5
                )
                imin = min(ys) - 10
                imax = max(ys) + 10
                if ymin > imin:
                    ymin = imin
                if ymax < imax:
                    ymax = imax
            vrois.append((ymin, ymax))

        self.drawCalibSpectra()
        self.rects = []
        for i, h in enumerate(hrois):
            v = vrois[i]
            rect = [None, None, None, None]
            # lines drawn x1y1 to x2y1, x2y1 to x2y2, x2y2 to x1y2, x1y2 to x1y1
            (rect[0],) = self.ax.plot(
                [h[0], h[1]],
                [v[0], v[0]],
                clip_on=False,
                color="red",
            )
            (rect[1],) = self.ax.plot(
                [h[1], h[1]],
                [v[0], v[1]],
                clip_on=False,
                color="red",
            )
            (rect[2],) = self.ax.plot(
                [h[1], h[0]],
                [v[1], v[1]],
                clip_on=False,
                color="red",
            )
            (rect[3],) = self.ax.plot(
                [h[0], h[0]],
                [v[1], v[0]],
                clip_on=False,
                color="red",
            )
            rect = [
                rect.copy(),
                (h[0], h[1], v[0], v[1]),
            ]
            self.rects.append(rect)
        self.sc.draw_idle()

    def calcHrois(self):
        # this section calculates the hrois
        self.hrois = []
        for i in self.rects:
            self.hrois.append(HROI(i[1][0], i[1][1]))
        # print("done")

    def calcEmap(self):
        try:
            scans = self.calibscans
        except Exception:
            self.error = ErrorWindow("emapCalib")
            return
        if self.emap_select_button.activated or len(self.rects) == 0:
            return
        self.emap_select_button.setDisabled(True)
        self.emap_calc_button.setDisabled(True)
        self.emap_save_button.setDisabled(False)
        self.calcHrois()
        self.emap = core.calcEMap(scans, self.hrois)
        self.drawEmap()

    def drawEmap(self):
        if self.ax is None:
            self.ax = self.sc.figure.add_subplot()
        self.ax.cla()
        self.ax.imshow(
            np.log(self.emap.values.swapaxes(0, 1)), origin="lower", cmap="binary"
        )
        self.sc.draw()

    def saveEmap(self):
        if self.emap is None:
            return
        dialog = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save Energy Map",
            filter="Numpy Array (*.npy)",
        )
        if not len(dialog[0]):
            return
        self.emap.saveToPath(dialog[0])

    def loadEmap(self):
        desk = pathlib.Path.home() / "Desktop"
        text = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open Energy Map", directory=str(desk), filter="Numpy Array (*.npy)"
        )
        if not len(text[0]):
            return
        self.emap = core.EnergyMap.loadFromPath(text[0])
        self.drawEmap()

    def runXES(self):
        if self.childWindow is not None:
            self.childWindow.close()
        self.childWindow = self.XESWindow(self)

    class XESWindow(QtWidgets.QMainWindow):
        """Window for viewing XES spectra"""

        def __init__(self, parent: QtWidgets.QMainWindow, *args, **kwargs):
            super(MainWindow.XESWindow, self).__init__(*args, **kwargs)

            # sets the main window as the parent
            self.parent = parent
            self.setWindowTitle("XES Window")

            # canvas for XES spectra and XES button for opening XES files
            self.sc = MplCanvas(self, width=5, height=4, dpi=100)
            self.ax = self.sc.figure.add_subplot()
            toolbar = NavigationToolbar(self.sc, self)
            self.xes_button = QtWidgets.QPushButton("XES Data...")
            self.xes_button.clicked.connect(self.loadXES)

            # Save all spectra button
            self.save_all_button = QtWidgets.QPushButton("Save All Spectra As...")
            self.save_all_button.clicked.connect(self.saveAllSpectra)
            self.save_all_button.setDisabled(True)

            self.combo_box = QtWidgets.QComboBox()
            self.combo_box.addItem("Red Gradient")
            self.combo_box.addItem("Green Gradient")
            self.combo_box.addItem("Blue Gradient")
            self.combo_box.addItem("Rainbow")
            self.combo_box.setCurrentIndex(0)

            # connects everything to the XES window
            widget = QtWidgets.QWidget()
            self.mlayout = QtWidgets.QGridLayout(widget)
            self.mlayout.addWidget(toolbar, 1, 1, AlignFlag.AlignLeft)
            self.mlayout.addWidget(self.sc, 2, 1, AlignFlag.AlignCenter)
            self.mlayout.addWidget(self.xes_button, 0, 0, AlignFlag.AlignCenter)
            self.mlayout.addWidget(self.combo_box, 1, 0, AlignFlag.AlignCenter)
            self.mlayout.addWidget(
                self.save_all_button, 2, 0, AlignFlag.AlignTop | AlignFlag.AlignLeft
            )
            self.mlayout.setColumnMinimumWidth(0, 240)
            self.mlayout.setColumnMinimumWidth(1, 500)

            self.setCentralWidget(widget)

            self.show()

        def closeEvent(self, event):
            super().closeEvent(event)
            self.deleteLater()

        # loads XES data (currently only able to load from TIF files)
        def loadXES(self):
            try:
                self.parent.emap
            except Exception:
                self.error = ErrorWindow("XESemap")
                return

            self.filenames = QtWidgets.QFileDialog.getOpenFileNames(
                filter="TIF Files (*.tif *.tiff)"
            )
            if self.filenames is None or len(self.filenames[0]) == 0:
                return
            self.checks = QtWidgets.QScrollArea()
            self.checks.setMinimumWidth(240)
            self.check_widgets = QtWidgets.QWidget()
            self.checks_grid = QtWidgets.QGridLayout(self.check_widgets)

            emap = self.parent.emap
            # plots all XES spectra with 100(vertical) spacing between them.
            LoadWindow = LoadingBarWindow("Loading XES data...", len(self.filenames[0]))
            scanset = []
            for i in self.filenames[0]:
                scanset.append(calcXESSpectra(i, emap))
                LoadWindow.add()
                QtWidgets.QApplication.processEvents()
            LoadWindow.deleteLater()
            scanlen = len(scanset)

            if not self.combo_box.currentIndex():
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], ((scanlen - i) / scanlen, 0, 0), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            elif self.combo_box.currentIndex() == 1:
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], (0, (scanlen - i) / scanlen, 0), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            elif self.combo_box.currentIndex() == 2:
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], (0, 0, (scanlen - i) / scanlen), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            else:
                rainbow = (
                    (1, 0, 0),
                    (1, 0.5, 0),
                    (0.9, 0.9, 0),
                    (0, 1, 0),
                    (0, 0.5, 1),
                    (0, 0, 1),
                    (0.5, 0, 1),
                    (1, 0, 1),
                )
                self.spectra = [
                    self.Spectrum(self, scanset[i], rainbow[i % len(rainbow)], i + 3)
                    for i, _ in enumerate(scanset)
                ]

            self.disp_spectra = self.spectra.copy()

            all_button = QtWidgets.QPushButton()
            all_button.clicked.connect(self.allSpectra)
            all_button.setText("All")
            none_button = QtWidgets.QPushButton()
            none_button.clicked.connect(self.noSpectra)
            none_button.setText("None")
            invert_button = QtWidgets.QPushButton()
            invert_button.clicked.connect(self.invertSpectra)
            invert_button.setText("Invert")
            self.checks_grid.addWidget(all_button, 0, 0, AlignFlag.AlignLeft)
            self.checks_grid.addWidget(none_button, 1, 0, AlignFlag.AlignLeft)
            self.checks_grid.addWidget(invert_button, 2, 0, AlignFlag.AlignLeft)
            self.checks.setWidget(self.check_widgets)
            self.mlayout.addWidget(self.checks, 2, 0, AlignFlag.AlignCenter)

            self.save_all_button.setDisabled(False)
            self.stackSpectra()
            self.graphSpectra()

        def allSpectra(self):
            for i in self.spectra:
                i.box.setChecked(True)

        def noSpectra(self):
            for i in self.spectra:
                i.box.setChecked(False)

        def invertSpectra(self):
            for i in self.spectra:
                if i in self.disp_spectra:
                    i.box.setChecked(False)
                else:
                    i.box.setChecked(True)

        def stackSpectra(self):
            length = len(self.disp_spectra)
            for i in self.disp_spectra:
                i.current = i.base.copy()
                for j, _ in enumerate(i.base):
                    inc = 100 * length
                    i.increaseIntensity(inc, j)
                length -= 1

        def graphSpectra(self):
            self.ax.cla()
            for i in self.disp_spectra:
                self.ax.plot(i.energies, i.current, color=i.colour)
            self.sc.draw()

        def removeSpectrum(self, spectrum):
            self.disp_spectra.pop(self.disp_spectra.index(spectrum))
            self.stackSpectra()
            self.graphSpectra()

        def addSpectrum(self, spectrum):
            num = self.spectra.index(spectrum)
            count = 0
            for i in range(num):
                if self.spectra[i] in self.disp_spectra:
                    count += 1
            self.disp_spectra.insert(count, spectrum)
            self.stackSpectra()
            self.graphSpectra()

        def saveAllSpectra(self):
            dialog = QtWidgets.QFileDialog.getSaveFileName(
                self,
                "Save All Spectra",
                filter=("Excel Spreadsheet (*.xlsx) \n Simple Text Layout (*.txt)"),
            )
            direct = open(dialog[0], "+w")
            if dialog[1] == "Excel Spreadsheet (*.xlsx)":
                pass
            elif dialog[1] == "Simple Spreadsheet Layout (*.csv)":
                lines = ["" for _, _ in enumerate(self.spectra[0].energies)]
                lines.insert(0, "")
                lines.insert(1, "")
                for spect in self.spectra:
                    lines[0] += spect.name + ",,,"
                    lines[1] += "Emission Energy (eV),Counts,,"
                    texts = [
                        str(spect.energies[j]) + "," + str(spect.intensities[j]) + ",,"
                        for j, _ in enumerate(spect.energies)
                    ]
                    for k, string in enumerate(texts):
                        lines[k + 2] += string
                text = ""
                for line in lines:
                    text += line + "\n"
                direct.write(text)
                direct.close()

        class Spectrum:
            def __init__(self, parent, spectrum, colour, num):
                self.parent = parent
                self.energies = spectrum.energies
                self.intensities = spectrum.intensities
                self.base = spectrum.intensities.copy()
                self.current = self.base.copy()

                self.colour = colour

                t = self.parent.filenames[0][num - 3]
                self.name = t[t.rfind("/") + 1 :]
                self.box = QCheckBox()
                self.box.setChecked(True)
                self.box.stateChanged.connect(self.hide)
                self.box.setText(
                    self.name + ", " + str(tuple(int(i * 255) for i in colour))
                )

                self.parent.checks_grid.addWidget(self.box, num, 0, AlignFlag.AlignLeft)

            def increaseIntensity(self, inc, pos):
                self.current[pos] += inc

            def hide(self, s):
                if s != QtCore.Qt.CheckState.Checked.value:
                    self.parent.removeSpectrum(self)
                else:
                    self.parent.addSpectrum(self)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setWindowIcon(QtGui.QIcon("spc-logo-nobg.png"))
    W = MainWindow()
    # sys.exit(app.exec())
    app.exec()
