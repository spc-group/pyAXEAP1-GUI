from PyQt6 import QtWidgets, QtCore
import pyqtgraph as pg
from ErrorWindow import ErrorWindow
from LoadingBarWindow import LoadingBarWindow
from functions import calcXESSpectra
from openpyxl import Workbook as ExWorkbook
from openpyxl.utils import get_column_letter as getColumnLetter
from SpectrumClass import Spectrum

AlignFlag = QtCore.Qt.AlignmentFlag


class XESWindow(QtWidgets.QMainWindow):
    """Window for viewing XES spectra"""

    def __init__(self, parent: QtWidgets.QMainWindow, *args, **kwargs):
        super(XESWindow, self).__init__(*args, **kwargs)

        # sets the main window as the parent
        self.parent = parent
        self.setWindowTitle("XES Window")
        self.xes_button = QtWidgets.QPushButton("XES Data...")
        self.xes_button.clicked.connect(self.loadXES)
        self.xes_button.setFixedSize(140, 30)

        self.sc = pg.plot()
        self.sc.setBackground("w")
        label_style = {"color": "#444", "font-size": "14pt"}
        self.sc.plotItem.getAxis("left").setLabel(text="Signal Counts", **label_style)
        self.sc.plotItem.getAxis("bottom").setLabel(
            text="Emission Energy", **label_style
        )

        # Save all spectra button
        self.save_all_button = QtWidgets.QPushButton("Save All Spectra As...")
        self.save_all_button.clicked.connect(self.saveAllSpectra)
        self.save_all_button.setDisabled(True)
        self.save_all_button.setFixedSize(140, 30)

        self.colour_box = QtWidgets.QComboBox()
        self.colour_box.setFixedSize(140, 30)
        self.colour_box.addItem("Red Gradient")
        self.colour_box.addItem("Red Gradient (inverted)")
        self.colour_box.addItem("Green Gradient")
        self.colour_box.addItem("Green Gradient (inverted)")
        self.colour_box.addItem("Blue Gradient")
        self.colour_box.addItem("Blue Gradient (inverted)")
        self.colour_box.addItem("Rainbow")
        self.colour_box.setCurrentIndex(6)

        self.stack_type_box = QtWidgets.QComboBox()
        self.stack_type_box.setFixedSize(140, 30)
        self.stack_type_box.addItem("Spaced")
        self.stack_type_box.addItem("Stacked (no spacing)")
        self.stack_type_box.setCurrentIndex(0)

        self.refresh_button = QtWidgets.QPushButton("Refresh")
        self.refresh_button.setFixedSize(140, 30)
        self.refresh_button.setDisabled(True)
        self.refresh_button.clicked.connect(self.refreshSpectra)

        # connects everything to the XES window
        widget = QtWidgets.QWidget()
        self.mlayout = QtWidgets.QGridLayout(widget)
        self.mlayout.addWidget(self.sc, 2, 2, AlignFlag.AlignCenter)
        self.mlayout.addWidget(self.xes_button, 0, 0, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.colour_box, 0, 1, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.save_all_button, 1, 0, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.stack_type_box, 1, 1, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.refresh_button, 1, 2, AlignFlag.AlignLeft)
        self.mlayout.setColumnMinimumWidth(2, 500)

        self.setCentralWidget(widget)

        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()
        self.parent.childWindow = None

    # loads XES data (currently only able to load from TIF files)
    def loadXES(self):
        try:
            self.parent.emap
        except Exception:
            self.error = ErrorWindow("XESemap")
            return

        self.filenames = QtWidgets.QFileDialog.getOpenFileNames(
            filter="TIF Files (*.tif *.tiff)"
        )
        if self.filenames is None or len(self.filenames[0]) == 0:
            return
        self.checks = QtWidgets.QScrollArea()
        self.checks.setMinimumWidth(280)
        self.check_widgets = QtWidgets.QWidget()
        self.checks_grid = QtWidgets.QGridLayout(self.check_widgets)

        emap = self.parent.emap
        # plots all XES spectra with 100(vertical) spacing between them.
        LoadWindow = LoadingBarWindow("Loading XES data...", len(self.filenames[0]))
        scanset = []
        for i in self.filenames[0]:
            scanset.append(calcXESSpectra(i, emap))
            LoadWindow.add()
            QtWidgets.QApplication.processEvents()
        LoadWindow.deleteLater()
        scanlen = len(scanset)
        index = self.colour_box.currentIndex()

        if index == 0:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (255 * (scanlen - i) / scanlen, 0, 0),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        elif index == 1:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (255 * (i) / scanlen, 0, 0),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        elif index == 2:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (0, 255 * (scanlen - i) / scanlen, 0),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        elif index == 3:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (0, 255 * (i) / scanlen, 0),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        elif index == 4:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (0, 0, 255 * (scanlen - i) / scanlen),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        elif index == 5:
            self.spectra = [
                Spectrum(
                    self,
                    scanset[i],
                    (0, 0, 255 * (i) / scanlen),
                    i + 3,
                )
                for i, _ in enumerate(scanset)
            ]
        else:
            rainbow = (
                (255, 0, 0),  # red
                (255, 130, 0),  # orange
                (220, 220, 0),  # yellow (lowered values so not as bright)
                (0, 255, 0),  # green
                (0, 130, 255),  # cyan
                (0, 0, 255),  # blue
                (130, 0, 255),  # purple(ish)
                (240, 0, 240),  # also purple(ish)
            )
            self.spectra = [
                Spectrum(self, scanset[i], rainbow[i % len(rainbow)], i + 1)
                for i, _ in enumerate(scanset)
            ]

        self.disp_spectra = self.spectra.copy()

        self.refresh_button.setDisabled(False)

        all_button = QtWidgets.QPushButton()
        all_button.clicked.connect(self.allSpectra)
        all_button.setText("All")
        none_button = QtWidgets.QPushButton()
        none_button.clicked.connect(self.noSpectra)
        none_button.setText("None")
        invert_button = QtWidgets.QPushButton()
        invert_button.clicked.connect(self.invertSpectra)
        invert_button.setText("Invert")
        self.checks_grid.addWidget(all_button, 0, 0, AlignFlag.AlignLeft)
        self.checks_grid.addWidget(none_button, 0, 1, AlignFlag.AlignLeft)
        self.checks_grid.addWidget(invert_button, 0, 2, AlignFlag.AlignLeft)
        self.checks.setWidget(self.check_widgets)
        self.mlayout.addWidget(
            self.checks, 2, 0, 1, 2, AlignFlag.AlignHCenter | AlignFlag.AlignTop
        )

        self.save_all_button.setDisabled(False)
        self.stackSpectra()
        self.graphSpectra()

    def refreshSpectra(self):
        self.stackSpectra()
        self.graphSpectra()

    def allSpectra(self):
        for i in self.spectra:
            i.restack_now = False
            i.box.setChecked(True)
            i.restack_now = True
        self.refreshSpectra()

    def noSpectra(self):
        for i in self.spectra:
            i.restack_now = False
            i.box.setChecked(False)
            i.restack_now = True
        self.refreshSpectra()

    def invertSpectra(self):
        for i in self.spectra:
            i.restack_now = False
            if i in self.disp_spectra:
                i.box.setChecked(False)
            else:
                i.box.setChecked(True)
            i.restack_now = True
        self.refreshSpectra()

    def stackSpectra(self):
        if self.stack_type_box.currentIndex():
            amt = 0
        else:
            amt = 100
        for index, i in enumerate(self.disp_spectra):
            i.current = i.base.copy()
            for j, _ in enumerate(i.base):
                inc = amt * index
                i.increaseIntensity(inc, j)

    def graphSpectra(self):
        self.sc.plotItem.clear()
        for i in self.disp_spectra:
            self.sc.plotItem.plot(
                i.energies, i.current, pen=pg.mkPen(color=i.colour, width=2)
            )

    def removeSpectrum(self, spectrum):
        self.disp_spectra.remove(spectrum)
        if spectrum.restack_now:
            self.refreshSpectra()

    def addSpectrum(self, spectrum):
        num = self.spectra.index(spectrum)
        count = 0
        for i in range(num):
            if self.spectra[i] in self.disp_spectra:
                count += 1
        self.disp_spectra.insert(count, spectrum)
        if spectrum.restack_now:
            self.refreshSpectra()

    def saveAllSpectra(self):
        dialog = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save All Spectra",
            filter=("Excel Spreadsheet (*.xlsx) \n Simple Text Layout (*.txt)"),
        )

        if dialog[1] == "Excel Spreadsheet (*.xlsx)":
            wb = ExWorkbook()
            ws = wb.active

            lines = [[] for _, _ in enumerate(self.spectra[0].energies)]
            lines.insert(0, [])
            lines.insert(1, [])
            for spect in self.spectra:
                lines[0].append(spect.name[: spect.name.rfind(".")])
                lines[0].append("")
                lines[0].append("")
                lines[1].append("Emission Energy (eV)")
                lines[1].append("Counts")
                lines[1].append("")
                texts = [
                    [str(spect.energies[j]), str(spect.intensities[j]), ""]
                    for j, _ in enumerate(spect.energies)
                ]
                for k, item in enumerate(texts):
                    for l in range(3):
                        lines[k + 2].append(item[l])
            for i, line in enumerate(lines, 1):
                for j, item in enumerate(line, 1):
                    try:
                        n = float(item)
                    except Exception:
                        n = item
                    ws.cell(i, j).value = n
            for i in range(int(len(lines[0]) / 3)):
                ws.merge_cells(
                    start_row=1,
                    end_row=1,
                    start_column=i * 3 + 1,
                    end_column=i * 3 + 2,
                )
                ws.column_dimensions[getColumnLetter(i * 3 + 1)].width = 20
            wb.save(dialog[0])
            wb.close()

        elif dialog[1] == "Simple Spreadsheet Layout (*.csv)":
            direct = open(dialog[0], "+w")
            lines = ["" for _, _ in enumerate(self.spectra[0].energies)]
            lines.insert(0, "")
            lines.insert(1, "")
            for spect in self.spectra:
                lines[0] += spect.name[spect.name.rfind(".")] + ",,,"
                lines[1] += "Emission Energy (eV),Counts,,"
                texts = [
                    str(spect.energies[j]) + "," + str(spect.intensities[j]) + ",,"
                    for j, _ in enumerate(spect.energies)
                ]
                for k, string in enumerate(texts):
                    lines[k + 2] += string
            text = ""
            for line in lines:
                text += line + "\n"
            direct.write(text)
            direct.close()
