from PyQt6.QtWidgets import QDialog
from PyQt6 import QtWidgets


class SettingsWindow(QDialog):
    def __init__(self, parent, settings):
        super(SettingsWindow, self).__init__(parent=parent)
        self.parent = parent
        save = QtWidgets.QDialogButtonBox.StandardButton.Save
        cancel = QtWidgets.QDialogButtonBox.StandardButton.Cancel
        buttons = QtWidgets.QDialogButtonBox(save | cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.closeEvent)

    def save(self):
        pass
