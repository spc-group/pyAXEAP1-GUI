from PyQt6 import QtWidgets, QtCore, QtGui

AlignFlag = QtCore.Qt.AlignmentFlag


class CalibFile:
    def __init__(self, parent, name, row):
        self.name = name
        self.parent = parent

        self.label = QtWidgets.QLabel(self.name[self.name.rfind("/") + 1 :])
        self.val = cSpinBox()
        self.val.setMaximum(1000000)
        self.val.setDecimals(4)
        self.val.setMinimumWidth(160)
        self.val
        self.parent.calib_grid.addWidget(self.label, row, 0, AlignFlag.AlignLeft)
        self.parent.calib_grid.addWidget(self.val, row, 1, AlignFlag.AlignLeft)

    def changeVal(self, val):
        self.val.setValue(val)

    def getVal(self):
        return self.val.value()


class cSpinBox(QtWidgets.QDoubleSpinBox):
    def __init__(self):
        super().__init__()

    def wheelEvent(self, event):
        event.ignore()
