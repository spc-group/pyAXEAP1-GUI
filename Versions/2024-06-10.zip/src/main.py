# :author: Alexander Berno

import axeap.core as core
from axeap.core.conventions import X
import sys
import matplotlib
from functions import *

matplotlib.use("QTAgg")

from PyQt6 import QtCore, QtWidgets
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QCheckBox
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg,
    NavigationToolbar2QT as NavigationToolbar,
)
from matplotlib.figure import Figure

app = QtWidgets.QApplication(sys.argv)


# Creates a loading bar window for any loading processes
class LoadingBarWindow(QtWidgets.QProgressDialog):
    def __init__(self, message: str, num: int, *args, **kwargs):
        super(LoadingBarWindow, self).__init__(*args, **kwargs)

        self.setLabelText(message)
        self.setAutoClose(True)
        self.canceled.connect(self.cancel)
        self.setValue(0)
        self.setMaximum(num)

        self.show()

    def add(self):
        self.setValue(self.value() + 1)

    def cancel(self):
        pass


# Creates a window to display errors/problems for users
class ErrorWindow(QtWidgets.QDialog):

    def __init__(self, error: str = "None", *args, **kwargs):
        super(ErrorWindow, self).__init__(*args, **kwargs)

        self.setWindowTitle("Error")
        self.setMinimumHeight(120)
        # error syntax is "[attempted calculation/execution] [reason for not working]"
        if error == "None":
            return
        elif error == "emapCalib":
            labeltext = "You must select calibration data to calculate the energy map."
        elif error == "XESemap":
            labeltext = "You must calculate an energy map to calculate XES spectra."

        button = QtWidgets.QDialogButtonBox.StandardButton.Ok
        label = QtWidgets.QLabel(text=labeltext)
        button_box = QtWidgets.QDialogButtonBox(button)
        button_box.accepted.connect(self.accept)

        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(label)
        layout.addWidget(button_box, alignment=Qt.AlignmentFlag.AlignCenter)

        self.setLayout(layout)
        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()


class MplCanvas(FigureCanvasQTAgg):

    def __init__(
        self,
        parent: QtWidgets.QMainWindow = None,
        width: int = 5,
        height: int = 4,
        dpi: int = 100,
    ):
        fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(fig)


class MainWindow(QtWidgets.QMainWindow):
    """Main Window for application. Allows the viewing of data."""

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.setWindowTitle("Main Window")

        # Canvas and Toolbar for main window
        self.sc = MplCanvas(self, width=5, height=4, dpi=100)
        self.ax = self.sc.figure.add_subplot()
        toolbar = NavigationToolbar(self.sc, self)

        # button for opening calibration data
        cali_button = QtWidgets.QPushButton("Calibration Data...")
        cali_button.clicked.connect(self.openPath)

        # button for calculating energy map
        emap_button = QtWidgets.QPushButton("Calculate Energy Map")
        emap_button.clicked.connect(self.calcEmap)

        # button for opening XES menu
        xes_button = QtWidgets.QPushButton("XES")
        xes_button.clicked.connect(self.runXES)

        # main "widget"; basically everything that is within the main window
        widget = QtWidgets.QWidget()

        # connects everything to the window with grid organization
        self.mlayout = QtWidgets.QGridLayout(widget)
        self.mlayout.addWidget(cali_button, 0, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(emap_button, 1, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(xes_button, 2, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(toolbar, 2, 1, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(self.sc, 3, 1, Qt.AlignmentFlag.AlignCenter)
        self.mlayout.setColumnMinimumWidth(0, 240)
        self.mlayout.setColumnMinimumWidth(1, 500)

        self.setCentralWidget(widget)

        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()

    def openPath(self):
        self.calibfiledir = QtWidgets.QFileDialog.getExistingDirectory()

        if self.calibfiledir is not None and self.calibfiledir != "":
            self.calibscans = loadCalib(self.calibfiledir)
            self.drawCalibSpectra()

    def drawCalibSpectra(self):
        points = getCoordsFromScans(self.calibscans, reorder=True, cuts=(3, 10))
        self.ax.cla()
        for i in points:
            m = max(i[2])
            self.ax.scatter(i[0], i[1], s=0.1, color="red", alpha=[j / m for j in i[2]])
        self.sc.draw()

    # temp class for calculating horizontal regions of interest
    def calcHrois(self):
        # this section calculates the hrois
        s = self.calibscans.items[0]
        numcrystals = 8
        min_width = s.dims[X] / numcrystals / 3
        self.hrois = core.calcHROIs(
            s.mod(cuts=(3, 10)), min_width=min_width, group_buffer=10
        )
        # print("done")

    def calcEmap(self):
        try:
            scans = self.calibscans
        except:
            self.error = ErrorWindow("emapCalib")
        else:
            self.calcHrois()
            self.emap = core.calcEMap(scans, self.hrois)

    def runXES(self):
        self.childWindow = self.XESWindow(self)

    class XESWindow(QtWidgets.QMainWindow):
        """Window for viewing XES spectra"""

        def __init__(self, parent: QtWidgets.QMainWindow, *args, **kwargs):
            super(MainWindow.XESWindow, self).__init__(*args, **kwargs)

            # sets the main window as the parent
            self.parent = parent
            self.setWindowTitle("XES Window")

            # canvas for XES spectra and XES button for opening XES files
            self.sc = MplCanvas(self, width=5, height=4, dpi=100)
            self.ax = self.sc.figure.add_subplot()
            toolbar = NavigationToolbar(self.sc, self)
            self.xes_button = QtWidgets.QPushButton("XES Data...")
            self.xes_button.clicked.connect(self.loadXES)

            # connects everything to the XES window
            widget = QtWidgets.QWidget()
            self.mlayout = QtWidgets.QGridLayout(widget)
            self.mlayout.addWidget(toolbar, 1, 1, Qt.AlignmentFlag.AlignLeft)
            self.mlayout.addWidget(self.sc, 2, 1, Qt.AlignmentFlag.AlignCenter)
            self.mlayout.addWidget(self.xes_button, 0, 0, Qt.AlignmentFlag.AlignCenter)
            self.mlayout.setColumnMinimumWidth(0, 240)
            self.mlayout.setColumnMinimumWidth(1, 500)

            self.setCentralWidget(widget)

            self.show()

        def closeEvent(self, event):
            super().closeEvent(event)
            self.deleteLater()

        # loads XES data (currently only able to load from TIF files)
        def loadXES(self):
            try:
                self.parent.emap
            except:
                self.error = ErrorWindow("XESemap")
                return

            self.filenames = QtWidgets.QFileDialog.getOpenFileNames(
                filter="TIF Files (*.tif *.tiff)"
            )
            if self.filenames is None or len(self.filenames[0]) == 0:
                return
            self.checks = QtWidgets.QScrollArea()
            self.checks.setMinimumWidth(240)
            self.check_widgets = QtWidgets.QWidget()
            self.checks_grid = QtWidgets.QGridLayout(self.check_widgets)

            emap = self.parent.emap
            # plots all XES spectra with 100Y spacing between them.
            scanset = calcXESSpectra(self.filenames[0], emap)
            self.spectra = [
                self.Spectrum(self, scanset[i], i + 3) for i, _ in enumerate(scanset)
            ]

            self.disp_spectra = self.spectra.copy()

            all_button = QtWidgets.QPushButton()
            all_button.clicked.connect(self.allSpectra)
            all_button.setText("All")
            none_button = QtWidgets.QPushButton()
            none_button.clicked.connect(self.noSpectra)
            none_button.setText("None")
            invert_button = QtWidgets.QPushButton()
            invert_button.clicked.connect(self.invertSpectra)
            invert_button.setText("Invert")
            self.checks_grid.addWidget(all_button, 0, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks_grid.addWidget(none_button, 1, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks_grid.addWidget(invert_button, 2, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks.setWidget(self.check_widgets)
            self.mlayout.addWidget(self.checks, 2, 0, Qt.AlignmentFlag.AlignCenter)

            self.stackSpectra()
            self.graphSpectra()

        def allSpectra(self):
            for i in self.spectra:
                i.box.setChecked(True)

        def noSpectra(self):
            for i in self.spectra:
                i.box.setChecked(False)

        def invertSpectra(self):
            for i in self.spectra:
                if i in self.disp_spectra:
                    i.box.setChecked(False)
                else:
                    i.box.setChecked(True)

        def stackSpectra(self):
            length = len(self.disp_spectra)
            for i in self.disp_spectra:
                i.current = i.base.copy()
                for j, _ in enumerate(i.base):
                    inc = 100 * length
                    i.increaseIntensity(inc, j)
                length -= 1

        def graphSpectra(self):
            self.ax.cla()
            for i in self.disp_spectra:
                self.ax.plot(i.energies, i.current)
            self.sc.draw()

        def removeSpectrum(self, spectrum):
            self.disp_spectra.pop(self.disp_spectra.index(spectrum))
            self.stackSpectra()
            self.graphSpectra()

        def addSpectrum(self, spectrum):
            num = self.spectra.index(spectrum)
            count = 0
            for i in range(num):
                if self.spectra[i] in self.disp_spectra:
                    count += 1
            self.disp_spectra.insert(count, spectrum)
            self.stackSpectra()
            self.graphSpectra()

        class Spectrum:
            def __init__(self, parent, spectrum, num):
                self.parent = parent
                self.energies = spectrum.energies
                self.base = spectrum.intensities.copy()
                self.current = self.base.copy()
                t = self.parent.filenames[0][num - 3]
                self.name = t[t.rfind("/") + 1 :]
                self.box = QCheckBox()
                self.box.setChecked(True)
                self.box.stateChanged.connect(self.hide)
                self.box.setText(self.name)

                self.parent.checks_grid.addWidget(
                    self.box, num, 0, Qt.AlignmentFlag.AlignLeft
                )

            def increaseIntensity(self, inc, pos):
                self.current[pos] += inc

            def hide(self, s):
                if s != Qt.CheckState.Checked.value:
                    self.parent.removeSpectrum(self)
                else:
                    self.parent.addSpectrum(self)


W = MainWindow()
app.exec()
