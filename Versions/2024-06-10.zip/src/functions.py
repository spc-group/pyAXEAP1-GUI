# :author: Alexander Berno


"""Calibration functions.

This file contains functions used for calibration.
"""

from pathlib import Path
from axeap import core
from axeap import utils
import os
import numpy as np


def loadCalib(file_dir: Path, run_info=None, validate: bool = True):
    """Loads scans from each scan file.
    Assumed that this is only used to load calibration scans.

    Parameters
    ----------
    file_dir: directory, or tuple
        should be a path to a folder containing the calibration files
        or a list of paths to each individual calibration file.
    run_info: directory, optional
        this should be a path to the calibration run info file, the file
        titled the same as the calibration folder.
    validate: boolean, optional
        default value is True.
        choose whether or not to validate the scans before returning them.
        validation requires a run_info file, either contained in the file_dir
        or given explicitly.

    NOTE: run_info should be given when file_dir is list_like or if the
        run info file is not contained in the file_dir directory.

    Returns
    -------
    :obj:`core.ScanSet`
        set of all scans from calibration run.
    """

    inst = (str, os.PathLike)
    if isinstance(file_dir, inst):
        # creates a ScanSet of all scans from the file directory (currently only .tif files)
        calib_scans = core.ScanSet.loadFromPath(file_dir)

    else:
        calib_scans = []
        for i in file_dir:
            calib_scans.append(core.Scan.loadFromPath(i))
        calib_scans = core.ScanSet(calib_scans)

    # adds run info if directory is given
    if run_info is not None:
        calib_scans.addCalibRunInfo(core.CalibRunInfo(run_info))

    # # loops through scans and validates them so that no non-scan files are used.
    # # essentially checks that each file has points in it.
    # if validate:
    #     validated_scans = [
    #         s
    #         for s in calib_scans.items
    #         if len(core.calcVROIs(s.mod(cuts=(5, 10)), 20, 20)) == 1
    #     ]
    #     calib_scans = core.ScanSet(validated_scans)

    return calib_scans


def getCoordsFromScans(scans, reorder: bool = False, *args, **kwargs):
    """Gets the coordinates and intensities of points from scan objects.
    Centralizes image loading since image loading is generally done
    with the intention of then getting coordinates afterward.

    Parameters
    ----------
    scans: :obj:`core.Scan` or :obj:`core.ScanSet`
        expects either a core.Scan object or a list of core.Scan objects.
        the order of the list is the order the coordinates and intensities
        will be returned in.
    reorder: :obj:`bool`
        default value is False.
        if True, the coordinates and intensities will be placed in their own
        arrays, to be used in matplot plotting.
        Example array:
            ((x1, x2, x3, ...), (x1, y2, y3, ...), (s1, s2, s3, ...))
        if False, they will be kept as given (organized by scan).
        Example tuple:
            ((x1, y1, s1),(x2, y2, s2),(x3, y3, s3),...)

    Other Parameters (from core.Scan.getImg()):
        cuts : :obj:`tuple`, optional
            Pair of values (l,h) where any pixel values with intensity <l or
            >h are set to 0.
        scale : :obj:`float`, optional
            Number to scale all intensity values in image by.
        blur : :obj:`int`, optional
            Kernel size of gaussian blur to apply to image.
        roi : :obj:`.core.ROI`, optional
            Region of interest to which to restrict image. The rest of the image
            will be masked off.

    Returns
    -------
    if 'scans' is a single scan:
        numpy array of coordinates and intensities from that scan.
    if 'scans' is multiple scans:
        list of numpy arrays of coordinates and intensities, kept in original scan order.

    """

    if type(scans) is core.Scan:
        image = scans.getImg(*args, **kwargs)
        points = np.array(utils.getCoordsFromImage(image))
        if reorder:
            x = [i[0] for i in points]
            y = [i[1] for i in points]
            s = [i[2] for i in points]
            points = np.array([x, y, s])

    else:
        points = []
        for scan in scans:
            image = scan.getImg(*args, **kwargs)
            p = np.array(utils.getCoordsFromImage(image))
            if reorder:
                x = [i[0] for i in p]
                y = [i[1] for i in p]
                s = [i[2] for i in p]
                points.append(np.array([x, y, s]))
            else:
                points.append(p)

    return points


def calcXESSpectra(file_dir: Path, emap: core.EnergyMap):
    """Calculates XES spectra for XES scans using a given energy map.

    Parameters
    ----------
    file_dir: directory, or :obj:`tuple`
        accepts a file directory, list of file directories, or folder directory.
        this is the directory of the XES scan files to be the base of the spectra calculation.
    emap: :obj:`core.emap.EnergyMap`
        energy map for calculating spectra. should be made using calibration data.

    Returns
    -------
    :obj:`core.spectra.Spectra`
    or list of :obj:`core.spectra.Spectra`
    """

    try:
        scans = core.ScanSet.loadFromPath(file_dir)
        if len(scans.items) == 0:
            scan = core.Scan.loadFromPath(file_dir)
            return emap.calcSpectra(scan)
    except:
        scans = []
        for i in file_dir:
            scans.append(core.Scan.loadFromPath(i))
        scans = core.ScanSet(scans)

    spectra = []
    for i in scans:
        spectra.append(emap.calcSpectra(i))
    return spectra
