# :author: Alexander Berno

import axeap.core as core
import sys
import matplotlib
import matplotlib.patches
import multiprocessing
from axeap.core.roi import HROI
from math import log
import pathlib
from openpyxl import Workbook as ExWorkbook
from openpyxl.utils import get_column_letter as getColumnLetter


from RegionClass import Region
from RectangleClass import Rectangle
from LoadingBarWindow import LoadingBarWindow
from ApproxWindow import ApproxWindow
from ErrorWindow import ErrorWindow
from GetPoints import GetPoints
from functions import *

multiprocessing.freeze_support()

matplotlib.use("QTAgg")

from PyQt6 import QtCore, QtWidgets, QtGui

from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg,
    NavigationToolbar2QT as NavigationToolbar,
)
from matplotlib.figure import Figure

# Alignment flags are used to place items in a window.
AlignFlag = QtCore.Qt.AlignmentFlag

# default directory for file selection menus (Desktop)
desktop_directory = str(pathlib.Path.home() / "Desktop")


# Canvas class, used to generate the canvas for plotting.
class MplCanvas(FigureCanvasQTAgg):
    """Simple Canvas class, used to generate main canvas for plotting."""

    def __init__(
        self,
        parent,
        width,
        height,
        dpi=100,
    ):
        fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(fig)


# Main window
class MainWindow(QtWidgets.QMainWindow):
    """Main Window for application. Allows the viewing of data."""

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.sel_x1 = None
        self.sel_y1 = None
        self.sel_x2 = None
        self.sel_y2 = None
        self.sel_ax = None
        self.sel_rect = [None, []]
        self.rects = []
        self.drawn_calib = False
        self.left_button = False
        self.ax = None
        self.childWindow = None
        self.info_file = None

        self.setWindowTitle("pyAXEAP1")

        # Canvas and Toolbar for main window
        self.sc = MplCanvas(self, width=6.5, height=5, dpi=100)
        self.sc.mpl_connect("button_press_event", self.buttonPress)
        self.sc.mpl_connect("button_release_event", self.buttonRelease)
        self.sc.mpl_connect("motion_notify_event", self.pan)
        toolbar = NavigationToolbar(self.sc, self)

        # button for opening calibration data
        cali_button = QtWidgets.QPushButton("Import Images...")
        cali_button.setFixedSize(110, 30)
        cali_button.clicked.connect(self.openPath)

        # button for opening XES menu
        xes_button = QtWidgets.QPushButton("XES")
        xes_button.clicked.connect(self.runXES)

        # button for loading an existing energy map
        emap_load_button = QtWidgets.QPushButton("Load Energy Map...")
        emap_load_button.setFixedSize(120, 30)
        emap_load_button.clicked.connect(self.loadEmap)

        # energy map buttons
        emap_area = QtWidgets.QScrollArea()
        emap_widget = QtWidgets.QWidget()
        emap_grid = QtWidgets.QGridLayout(emap_widget)
        mincuts_label = QtWidgets.QLabel("Minimum Cuts")
        self.mincuts = QtWidgets.QSpinBox()
        self.mincuts.setMinimumSize(128, 20)
        self.mincuts.setMaximum(10000000)
        self.mincuts.setValue(3)
        maxcuts_label = QtWidgets.QLabel("Maximum cuts")
        self.maxcuts = QtWidgets.QSpinBox()
        self.maxcuts.setMinimumSize(128, 20)
        self.maxcuts.setMaximum(10000000)
        self.maxcuts.setValue(10000)
        self.approx_rois = QtWidgets.QPushButton("Set ROIs Automatically")
        self.approx_rois.setDisabled(True)
        self.approx_rois.clicked.connect(self.approxROIs)
        self.emap_select_button = QtWidgets.QPushButton("Edit ROIs")
        self.emap_select_button.setStyleSheet("background-color: gray")
        self.emap_select_button.setDisabled(True)
        self.emap_select_button.clicked.connect(self.selectEmap)
        self.emap_select_button.activated = False
        self.load_info_file_button = QtWidgets.QPushButton("Load Information File")
        self.load_info_file_button.setDisabled(True)
        self.load_info_file_button.clicked.connect(self.loadInfoFile)
        self.emap_calc_button = QtWidgets.QPushButton("Caibrate")
        self.emap_calc_button.clicked.connect(self.calcEmap)
        self.emap_calc_button.setDisabled(True)
        self.emap_save_button = QtWidgets.QPushButton("Save Energy Map As...")
        self.emap_save_button.clicked.connect(self.saveEmap)
        self.emap_save_button.setDisabled(True)

        # energy map layout connections
        emap_grid.addWidget(mincuts_label, 0, 0)
        emap_grid.addWidget(self.mincuts, 0, 1)
        emap_grid.addWidget(maxcuts_label, 1, 0)
        emap_grid.addWidget(self.maxcuts, 1, 1)
        emap_grid.addWidget(self.approx_rois, 2, 0)
        emap_grid.addWidget(self.emap_select_button, 2, 1)
        emap_grid.addWidget(self.load_info_file_button, 3, 0)
        emap_grid.addWidget(self.emap_calc_button, 3, 1)
        emap_grid.addWidget(self.emap_save_button, 4, 0)
        emap_area.setWidget(emap_widget)

        # main "widget"; basically everything that is within the main window
        mwidget = QtWidgets.QWidget()

        # connects everything to the window with grid organization
        self.mlayout = QtWidgets.QGridLayout(mwidget)
        self.mlayout.addWidget(cali_button, 0, 0, AlignFlag.AlignLeading)
        self.mlayout.addWidget(emap_load_button, 0, 1, AlignFlag.AlignLeft)
        self.mlayout.addWidget(xes_button, 1, 0, AlignFlag.AlignLeft)
        self.mlayout.addWidget(
            emap_area, 2, 0, 1, 2, AlignFlag.AlignLeft | AlignFlag.AlignTop
        )
        self.mlayout.addWidget(toolbar, 1, 2, AlignFlag.AlignLeft)
        self.mlayout.addWidget(self.sc, 2, 2, 2, 1, AlignFlag.AlignCenter)
        self.mlayout.setColumnMinimumWidth(2, 500)

        self.setCentralWidget(mwidget)

        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()

    def openPath(self):
        self.calibfiledir = QtWidgets.QFileDialog.getOpenFileNames(
            parent=self, directory=desktop_directory, filter="TIF Files (*.tif *.tiff)"
        )

        if self.calibfiledir[0] != [] and self.calibfiledir[1] != "":
            self.calibscans = loadCalib(self.calibfiledir[0])
            self.getCalibSpectra()

    def loadInfoFile(self):
        self.info_file = QtWidgets.QFileDialog.getOpenFileName(
            parent=self, directory=desktop_directory
        )
        if self.info_file[1] != "":
            try:
                self.calibscans.addCalibRunInfo(core.CalibRunInfo(self.info_file))
            except Exception or Warning:
                self.error = ErrorWindow("badInfoFile")
                return

    def getCalibSpectra(self):
        minc = self.mincuts.value()
        maxc = self.maxcuts.value()
        if minc > maxc:
            self.error = ErrorWindow("minmaxcuts")
            return
        self.rects = []
        self.LoadWindow = LoadingBarWindow(
            "Loading calibration data...", len(self.calibscans)
        )
        self.points = []
        self.load_calib_thread = QtCore.QThread()
        self.load_calib_worker = GetPoints(scans=self.calibscans, cuts=(minc, maxc))
        self.load_calib_worker.moveToThread(self.load_calib_thread)
        self.load_calib_thread.started.connect(self.load_calib_worker.run)
        self.load_calib_worker.finished.connect(self.load_calib_thread.quit)
        self.load_calib_worker.finished.connect(self.load_calib_worker.deleteLater)
        self.load_calib_worker.finished.connect(self.drawCalibSpectra)
        self.load_calib_thread.finished.connect(self.load_calib_thread.deleteLater)
        self.load_calib_worker.progress.connect(self.addPoints)

        self.load_calib_thread.start()

    def addPoints(self, n):
        self.points.append(n)
        self.LoadWindow.add()

    def drawCalibSpectra(self):
        if self.ax is not None:
            self.ax.remove()
        self.ax = self.sc.figure.add_subplot()
        m = 0

        for i in self.points:
            if m < max(i[2]):
                m = max(i[2])
        for i in self.points:
            alpha = [
                (((0.1 - (0.5 / log(m / 3)) * log(3)) + (0.5 / log(m / 3)) * log(j)))
                for j in i[2]
            ]
            self.ax.scatter(i[0], i[1], s=0.1, color=(0.1, 0.1, 0.1), alpha=alpha)

        self.sc.draw()
        self.ax.set_xlim(auto=False)
        self.ax.set_ylim(auto=False)
        self.drawn_calib = True
        self.approx_rois.setDisabled(False)
        self.emap_calc_button.setDisabled(False)

    def selectEmap(self):
        if self.emap_select_button.activated:
            self.emap_select_button.setText("Select ROIs")
            self.emap_select_button.setStyleSheet("background-color: gray")
            self.emap_select_button.activated = False
            self.approx_rois.setDisabled(False)
            self.emap_calc_button.setDisabled(False)
        else:
            self.emap_select_button.setText("Finish Selection")
            self.emap_select_button.setStyleSheet("background-color: green")
            self.emap_select_button.activated = True
            self.approx_rois.setDisabled(True)
            self.emap_calc_button.setDisabled(True)

    def buttonPress(self, event):
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if (
            modifiers == QtCore.Qt.KeyboardModifier.ControlModifier
            or not self.drawn_calib
        ):
            return
        # begins drawing a rectangle over the grid
        if event.button == 1:
            if not self.emap_select_button.activated:
                return
            self.sel_ax = event.inaxes
            x = event.xdata
            y = event.ydata

            for j in self.rects:
                colsn = j.collide(x, y)
                if colsn:
                    if colsn[0] == "corner":
                        c = colsn[1]
                        self.movement_type = 0
                        self.sel_x2 = j.x[c.rx]
                        self.sel_y2 = j.y[c.ry]
                        self.sel_x1 = j.x[j.opp(c).rx]
                        self.sel_y1 = j.y[j.opp(c).ry]

                    elif colsn[0] == "sidex" or colsn[0] == "sidey":
                        s = colsn[1]
                        self.movement_type = colsn[0]
                        self.sel_x2 = j.x[s.rx]
                        self.sel_y2 = j.y[s.ry]
                        self.sel_x1 = j.x[j.opp(s).rx]
                        self.sel_y1 = j.y[j.opp(s).ry]

                    else:
                        self.movement_type = 1
                        self.sel_x1 = j.x1
                        self.sel_y1 = j.y1
                        self.sel_x2 = j.x2
                        self.sel_y2 = j.y2
                        self.old_x = x
                        self.old_y = y

                    j.undraw()
                    self.rects.remove(j)
                    break

            self.left_button = True
            if self.sel_x1 is None and self.sel_y1 is None:
                self.left_button = False
            self.sc.draw()
        # deletes a rectangle if the RMB is pressed over a rectangle
        elif event.button == 3:
            if not self.emap_select_button.activated:
                return

            x = event.xdata
            y = event.ydata
            for i in self.rects:
                if i.collide(x, y, True):
                    i.undraw()
                    self.rects.remove(i)
                    break
            self.sc.draw_idle()

    def buttonRelease(self, event):
        if not self.drawn_calib:
            return
        if event.button == 1:
            if not self.emap_select_button.activated or not self.left_button:
                return
            self.left_button = False

            rect = Region(
                self.sel_x1,
                self.sel_y1,
                self.sel_x2,
                self.sel_y2,
                self.sel_ax,
                self.sc.figure,
            )
            rect.draw(self.sel_ax)
            self.rects.append(rect)

            try:
                if self.sel_rect[0] is not None:
                    for i in self.sel_rect[1]:
                        i.remove()
            finally:
                self.sel_rect = [None, []]

            self.sel_x2 = None
            self.sel_y2 = None
            self.sel_x1 = None
            self.sel_y1 = None
            self.sel_ax = None
            self.sc.draw()

    def pan(self, event):
        if not self.drawn_calib:
            return
        if not self.emap_select_button.activated:
            return
        if self.sel_x1 is not None and self.sel_y1 is not None:
            x = event.xdata
            y = event.ydata
            if x is None or y is None:
                return

            if not self.movement_type:
                self.sel_x2 = x
                self.sel_y2 = y
            elif self.movement_type == "sidex":
                self.sel_y2 = y
            elif self.movement_type == "sidey":
                self.sel_x2 = x
            else:
                self.sel_x1 = self.sel_x1 + (x - self.old_x)
                self.sel_x2 = self.sel_x2 + (x - self.old_x)
                self.old_x = x
                self.sel_y1 = self.sel_y1 + (y - self.old_y)
                self.sel_y2 = self.sel_y2 + (y - self.old_y)
                self.old_y = y

            try:
                if self.sel_rect[0] is not None:
                    for i in self.sel_rect[1]:
                        i.remove()
            finally:
                self.sel_rect = [None, []]

            self.sel_rect[0] = Rectangle(
                self.sel_x1, self.sel_y1, self.sel_x2, self.sel_y2
            )
            self.sel_rect[1] = self.sel_rect[0].createLines(self.ax)
            self.sc.draw_idle()

    def approxROIs(self):
        self.ApproxWindow = ApproxWindow(self)
        self.ApproxWindow.finished.connect(self.doApproxROIs)

    def doApproxROIs(self):
        if self.ApproxWindow.value is None:
            return

        self.emap_select_button.setDisabled(False)

        numcrystals = self.ApproxWindow.value
        hrois, vrois = approximateROIs(
            numcrystals,
            self.mincuts.value(),
            self.maxcuts.value(),
            self.calibscans.items[0],
            self.points,
        )

        self.drawCalibSpectra()

        self.rects = []
        for i, h in enumerate(hrois):
            v = vrois[i]
            rect = Region(h[0], v[0], h[1], v[1], self.ax, self.sc.figure)
            rect.draw(self.ax)
            self.rects.append(rect)
        self.sc.draw_idle()

    def calcHrois(self):
        # this section calculates the hrois
        self.hrois = []
        for i in self.rects:
            self.hrois.append(HROI(i.x1, i.y1))
        # print("done")

    def calcEmap(self):
        if self.info_file is None:
            self.error = ErrorWindow("noInfo")
            return
        try:
            scans = self.calibscans
        except Exception:
            self.error = ErrorWindow("emapCalib")
            return
        if self.emap_select_button.activated or len(self.rects) == 0:
            return
        self.emap_select_button.setDisabled(True)
        self.emap_calc_button.setDisabled(True)
        self.emap_save_button.setDisabled(False)
        self.calcHrois()
        self.emap = core.calcEMap(scans, self.hrois)
        self.drawEmap()

    def drawEmap(self):
        if self.ax is None:
            self.ax = self.sc.figure.add_subplot()
        self.ax.cla()
        self.ax.imshow(
            np.log(self.emap.values.swapaxes(0, 1)), origin="lower", cmap="binary"
        )
        self.sc.draw()
        self.ax.set_xlim(auto=False)
        self.ax.set_ylim(auto=False)

    def saveEmap(self):
        if self.emap is None:
            return
        dialog = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save Energy Map",
            filter="Numpy Array (*.npy)",
        )
        if not len(dialog[0]):
            return
        self.emap.saveToPath(dialog[0])

    def loadEmap(self):

        text = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Open Energy Map",
            directory=str(desktop_directory),
            filter="Numpy Array (*.npy)",
        )
        if not len(text[0]):
            return
        self.emap = core.EnergyMap.loadFromPath(text[0])
        self.drawEmap()

    def runXES(self):
        if self.childWindow is not None:
            self.childWindow.close()
        self.childWindow = self.XESWindow(self)

    class XESWindow(QtWidgets.QMainWindow):
        """Window for viewing XES spectra"""

        def __init__(self, parent: QtWidgets.QMainWindow, *args, **kwargs):
            super(MainWindow.XESWindow, self).__init__(*args, **kwargs)

            # sets the main window as the parent
            self.parent = parent
            self.setWindowTitle("XES Window")

            # canvas for XES spectra and XES button for opening XES files
            self.sc = MplCanvas(self, width=5, height=4, dpi=100)
            self.ax = self.sc.figure.add_subplot()
            self.ax.set_title("Title")
            self.ax.xaxis.set_label("Emission Energy")
            self.ax.yaxis.set_label("Signal Counts (Relative)")
            toolbar = NavigationToolbar(self.sc, self)
            self.xes_button = QtWidgets.QPushButton("XES Data...")
            self.xes_button.clicked.connect(self.loadXES)

            # Save all spectra button
            self.save_all_button = QtWidgets.QPushButton("Save All Spectra As...")
            self.save_all_button.clicked.connect(self.saveAllSpectra)
            self.save_all_button.setDisabled(True)

            self.combo_box = QtWidgets.QComboBox()
            self.combo_box.addItem("Red Gradient")
            self.combo_box.addItem("Green Gradient")
            self.combo_box.addItem("Blue Gradient")
            self.combo_box.addItem("Rainbow")
            self.combo_box.setCurrentIndex(0)

            # connects everything to the XES window
            widget = QtWidgets.QWidget()
            self.mlayout = QtWidgets.QGridLayout(widget)
            self.mlayout.addWidget(toolbar, 1, 2, AlignFlag.AlignLeft)
            self.mlayout.addWidget(self.sc, 2, 2, AlignFlag.AlignCenter)
            self.mlayout.addWidget(self.xes_button, 0, 0, AlignFlag.AlignLeft)
            self.mlayout.addWidget(self.combo_box, 0, 1, AlignFlag.AlignLeft)
            self.mlayout.addWidget(self.save_all_button, 1, 0, AlignFlag.AlignLeft)
            self.mlayout.setColumnMinimumWidth(2, 500)

            self.setCentralWidget(widget)

            self.show()

        def closeEvent(self, event):
            super().closeEvent(event)
            self.deleteLater()
            self.parent.childWindow = None

        # loads XES data (currently only able to load from TIF files)
        def loadXES(self):
            try:
                self.parent.emap
            except Exception:
                self.error = ErrorWindow("XESemap")
                return

            self.filenames = QtWidgets.QFileDialog.getOpenFileNames(
                filter="TIF Files (*.tif *.tiff)"
            )
            if self.filenames is None or len(self.filenames[0]) == 0:
                return
            self.checks = QtWidgets.QScrollArea()
            self.checks.setMinimumWidth(260)
            self.check_widgets = QtWidgets.QWidget()
            self.checks_grid = QtWidgets.QGridLayout(self.check_widgets)

            emap = self.parent.emap
            # plots all XES spectra with 100(vertical) spacing between them.
            LoadWindow = LoadingBarWindow("Loading XES data...", len(self.filenames[0]))
            scanset = []
            for i in self.filenames[0]:
                scanset.append(calcXESSpectra(i, emap))
                LoadWindow.add()
                QtWidgets.QApplication.processEvents()
            LoadWindow.deleteLater()
            scanlen = len(scanset)

            if not self.combo_box.currentIndex():
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], ((scanlen - i) / scanlen, 0, 0), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            elif self.combo_box.currentIndex() == 1:
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], (0, (scanlen - i) / scanlen, 0), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            elif self.combo_box.currentIndex() == 2:
                self.spectra = [
                    self.Spectrum(
                        self, scanset[i], (0, 0, (scanlen - i) / scanlen), i + 3
                    )
                    for i, _ in enumerate(scanset)
                ]
            else:
                rainbow = (
                    (1, 0, 0),
                    (1, 0.5, 0),
                    (0.9, 0.9, 0),
                    (0, 1, 0),
                    (0, 0.5, 1),
                    (0, 0, 1),
                    (0.5, 0, 1),
                    (1, 0, 1),
                )
                self.spectra = [
                    self.Spectrum(self, scanset[i], rainbow[i % len(rainbow)], i + 1)
                    for i, _ in enumerate(scanset)
                ]

            self.disp_spectra = self.spectra.copy()

            all_button = QtWidgets.QPushButton()
            all_button.clicked.connect(self.allSpectra)
            all_button.setText("All")
            none_button = QtWidgets.QPushButton()
            none_button.clicked.connect(self.noSpectra)
            none_button.setText("None")
            invert_button = QtWidgets.QPushButton()
            invert_button.clicked.connect(self.invertSpectra)
            invert_button.setText("Invert")
            self.checks_grid.addWidget(all_button, 0, 0, AlignFlag.AlignLeft)
            self.checks_grid.addWidget(none_button, 0, 1, AlignFlag.AlignLeft)
            self.checks_grid.addWidget(invert_button, 0, 2, AlignFlag.AlignLeft)
            self.checks.setWidget(self.check_widgets)
            self.mlayout.addWidget(
                self.checks, 2, 0, 1, 2, AlignFlag.AlignHCenter | AlignFlag.AlignTop
            )

            self.save_all_button.setDisabled(False)
            self.stackSpectra()
            self.graphSpectra()

        def allSpectra(self):
            for i in self.spectra:
                i.box.setChecked(True)

        def noSpectra(self):
            for i in self.spectra:
                i.box.setChecked(False)

        def invertSpectra(self):
            for i in self.spectra:
                if i in self.disp_spectra:
                    i.box.setChecked(False)
                else:
                    i.box.setChecked(True)

        def stackSpectra(self):
            length = len(self.disp_spectra)
            for i in self.disp_spectra:
                i.current = i.base.copy()
                for j, _ in enumerate(i.base):
                    inc = 100 * length
                    i.increaseIntensity(inc, j)
                length -= 1

        def graphSpectra(self):
            self.ax.cla()
            for i in self.disp_spectra:
                self.ax.plot(i.energies, i.current, color=i.colour)
            self.sc.draw()

        def removeSpectrum(self, spectrum):
            self.disp_spectra.pop(self.disp_spectra.index(spectrum))
            self.stackSpectra()
            self.graphSpectra()

        def addSpectrum(self, spectrum):
            num = self.spectra.index(spectrum)
            count = 0
            for i in range(num):
                if self.spectra[i] in self.disp_spectra:
                    count += 1
            self.disp_spectra.insert(count, spectrum)
            self.stackSpectra()
            self.graphSpectra()

        def saveAllSpectra(self):
            dialog = QtWidgets.QFileDialog.getSaveFileName(
                self,
                "Save All Spectra",
                filter=("Excel Spreadsheet (*.xlsx) \n Simple Text Layout (*.txt)"),
            )

            if dialog[1] == "Excel Spreadsheet (*.xlsx)":
                wb = ExWorkbook()
                ws = wb.active

                lines = [[] for _, _ in enumerate(self.spectra[0].energies)]
                lines.insert(0, [])
                lines.insert(1, [])
                for spect in self.spectra:
                    lines[0].append(spect.name[: spect.name.rfind(".")])
                    lines[0].append("")
                    lines[0].append("")
                    lines[1].append("Emission Energy (eV)")
                    lines[1].append("Counts")
                    lines[1].append("")
                    texts = [
                        [str(spect.energies[j]), str(spect.intensities[j]), ""]
                        for j, _ in enumerate(spect.energies)
                    ]
                    for k, item in enumerate(texts):
                        for l in range(3):
                            lines[k + 2].append(item[l])
                for i, line in enumerate(lines, 1):
                    for j, item in enumerate(line, 1):
                        try:
                            n = float(item)
                        except Exception:
                            n = item
                        ws.cell(i, j).value = n
                for i in range(int(len(lines[0]) / 3)):
                    ws.merge_cells(
                        start_row=1,
                        end_row=1,
                        start_column=i * 3 + 1,
                        end_column=i * 3 + 2,
                    )
                    ws.column_dimensions[getColumnLetter(i * 3 + 1)].width = 20
                wb.save(dialog[0])
                wb.close()

            elif dialog[1] == "Simple Spreadsheet Layout (*.csv)":
                direct = open(dialog[0], "+w")
                lines = ["" for _, _ in enumerate(self.spectra[0].energies)]
                lines.insert(0, "")
                lines.insert(1, "")
                for spect in self.spectra:
                    lines[0] += spect.name[spect.name.rfind(".")] + ",,,"
                    lines[1] += "Emission Energy (eV),Counts,,"
                    texts = [
                        str(spect.energies[j]) + "," + str(spect.intensities[j]) + ",,"
                        for j, _ in enumerate(spect.energies)
                    ]
                    for k, string in enumerate(texts):
                        lines[k + 2] += string
                text = ""
                for line in lines:
                    text += line + "\n"
                direct.write(text)
                direct.close()

        class Spectrum:
            def __init__(self, parent, spectrum, colour, num):
                self.parent = parent
                self.energies = spectrum.energies
                self.intensities = spectrum.intensities
                self.base = spectrum.intensities.copy()
                self.current = self.base.copy()

                self.colour = colour

                t = self.parent.filenames[0][num - 3]
                self.name = t[t.rfind("/") + 1 :]
                self.box = QtWidgets.QCheckBox()
                self.box.setChecked(True)
                self.box.stateChanged.connect(self.hide)
                self.box.setText(
                    self.name + ", " + str(tuple(int(i * 255) for i in colour))
                )

                self.parent.checks_grid.addWidget(
                    self.box, num, 0, 1, 3, AlignFlag.AlignLeft
                )

            def increaseIntensity(self, inc, pos):
                self.current[pos] += inc

            def hide(self, s):
                if s != QtCore.Qt.CheckState.Checked.value:
                    self.parent.removeSpectrum(self)
                else:
                    self.parent.addSpectrum(self)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setWindowIcon(QtGui.QIcon("spc-logo-nobg.png"))
    W = MainWindow()
    # sys.exit(app.exec())
    app.exec()
