from PyQt6 import QtWidgets
from pyqtgraph import PlotWidget


class CanvasWidget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.graph = PlotWidget()
        self.mlayout = QtWidgets.QLayout(self)
