"""File containing Region class."""

from RectangleClass import Rectangle
from RectangleClass import genCollidePoint
from matplotlib import axes
from matplotlib import figure


def getAxisSize(ax: axes._axes.Axes, fig: figure.Figure):
    """
    Simple function to get the width and height of a given axis in pixels.

    Parameters
    ----------
    ax: :obj:`matplotlib.axes._axes.Axes`
        Axis to find width and height of.
    fig: :obj:`matplotlib.figure.Figure`
        Main figure that ax (the axis) is part of. Used for dpi scale reference.

    Returns
    -------
    width and height of the axis, as floats.
    """
    bbox = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
    width, height = bbox.width, bbox.height
    width *= fig.dpi
    height *= fig.dpi
    return width, height


class Region(Rectangle):
    """
    Extension of Rectangle class.
    Is itself a Rectangle, but also has sub Rectangles on each corner and side.
    These Rectangles are used for stretching and compressing the main Region in a Canvas.

    This class can handle all collision types with the main Region, including whether
            the collision is with one of the sub Rectangles or only the main Region.

    This class contains all methods for drawing the Region and its sub rectangles.
    This class also contains all methods for removing the Region from a Canvas (undraw).
    """

    def __init__(self, x1, y1, x2, y2, wh=False):
        """
        Initializes Region. This includes creating sub Rectangles of Region.
        Also organizes sub Rectangles for easy analysis.

        Parameters
        ----------
        x1: :obj:`int`
            First x coordinate of Region.
        y1: :obj:`int`
            First y coordinate of Region.
        x2: :obj:`int`
            Second x coordinate of Region, or width of Region.
        y2: :obj:`int`
            Second y coordinate of Region, or height of Region.
        ax: :obj:`matplotlib.axes._axes.Axes`
            Axis to draw the Region on. Used to find axis width and height for sizing sub Rectangles.
        wh: :obj:`bool`
            Boolean deciding whether x2,y2 are coordinates or width and height values.
        """
        super(Region, self).__init__(x1, y1, x2, y2, wh)

        self.inner = Rectangle(x1 + 1, y1 + 1, x2 - 1, y2 - 1)

        self.c1 = Rectangle(x1 - 1, y1 - 1, x1 + 1, y1 + 1)
        self.c1.rx = 0
        self.c1.ry = 0
        self.c2 = Rectangle(x2 - 1, y1 - 1, x2 + 1, y1 + 1)
        self.c2.rx = 1
        self.c2.ry = 0
        self.c3 = Rectangle(x2 - 1, y2 - 1, x2 + 1, y2 + 1)
        self.c3.rx = 1
        self.c3.ry = 1
        self.c4 = Rectangle(x1 - 1, y2 - 1, x1 + 1, y2 + 1)
        self.c4.rx = 0
        self.c4.ry = 1
        self.corder = (self.c1, self.c2, self.c3, self.c4)

        midx = int((x1 + x2) / 2)
        midy = int((y1 + y2) / 2)
        self.s1 = Rectangle(midx - 1, y1 - 1, midx + 1, y1 + 1)
        self.s1.rx = 0
        self.s1.ry = 0
        self.s1.dir = "x"
        self.s2 = Rectangle(x1 - 1, midy - 1, x1 + 1, midy + 1)
        self.s2.rx = 0
        self.s2.ry = 0
        self.s2.dir = "y"
        self.s3 = Rectangle(midx - 1, y2 - 1, midx + 1, y2 + 1)
        self.s3.rx = 1
        self.s3.ry = 1
        self.s3.dir = "x"
        self.s4 = Rectangle(x2 - 1, midy - 1, x2 + 1, midy + 1)
        self.s4.rx = 1
        self.s4.ry = 1
        self.s4.dir = "y"
        self.sorder = (self.s1, self.s2, self.s3, self.s4)

        self.cubes = self.corder + self.sorder

        self.rects = []

    def collide(self, x, y, only_main=False):
        """
        Checks collision of Region and sub Rectangles with a single point.

        Parameters
        ----------
        x: :obj:`float`
            x coordinate of point.
        y: :obj:`float`
            y coordinate of point.
        only_main: :obj:`bool`
            If True, only the main Region will be checked for collision, skipping the sub Rectangles.
        """
        if not only_main:
            for i in self.corder:
                if i.collidePoint(x, y):
                    return ("corner", i)

            for i in self.sorder:
                if i.collidePoint(x, y):
                    return (f"side{i.dir}", i)

        if self.inner.collidePoint(x, y):
            return ("main", None)

        return False

    def opp(self, rect):
        """
        Returns the opposite corner/side from the given sub Rectangle.
        """
        if rect in self.corder:
            return self.corder[(self.corder.index(rect) + 2) % 4]
        elif rect in self.sorder:
            return self.sorder[(self.sorder.index(rect) + 2) % 4]
        else:
            return None

    def draw(self, ax):
        """
        Draws the main Region as well as all sub Rectangles on a given axis.

        Parameters
        ----------
        ax: :obj:`matplotlib.axes._axes.Axes`
            Axis where Region will be plotted.
        """
        if type(self.x) is tuple:
            x1 = self.x1
            x2 = self.x2
            y1 = self.y1
            y2 = self.y2
        else:
            x1 = self.x
            x2 = self.x + self.w
            y1 = self.y
            y2 = self.y + self.h
        self.rects.append(ax.plot((x1, x2), (y1, y1), clip_on=False, color="red")[0])
        self.rects.append(ax.plot((x1, x2), (y2, y2), clip_on=False, color="red")[0])
        self.rects.append(ax.plot((x1, x1), (y1, y2), clip_on=False, color="red")[0])
        self.rects.append(ax.plot((x2, x2), (y1, y2), clip_on=False, color="red")[0])

        for i in self.cubes:
            self.rects.append(ax.plot(i.x, (i.y1, i.y1), clip_on=False, color="red")[0])
            self.rects.append(ax.plot(i.x, (i.y2, i.y2), clip_on=False, color="red")[0])
            self.rects.append(ax.plot((i.x1, i.x1), i.y, clip_on=False, color="red")[0])
            self.rects.append(ax.plot((i.x2, i.x2), i.y, clip_on=False, color="red")[0])

    def undraw(self):
        """
        Undraws (removes) all drawn rectangles, as drawn in the draw function.
        """
        for i in self.rects:
            i.remove()
        self.rects = []
