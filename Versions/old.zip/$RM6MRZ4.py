"""File containing Rectangle class as simple collision detector."""


def genCollidePoint(x, y, rect):
    """
    Simple collision detector for a given point and rectangle region.

    x, y should be floats or integers.

    rect should be a Rectangle.

    Returns True if they collide, False otherwise.
    """
    if type(rect.x) is tuple:
        if rect.x1 < x < rect.x2 and rect.y1 < y < rect.y2:
            return True
    else:
        if rect.x < x < rect.x + rect.w and rect.y < y < rect.y + rect.h:
            return True
    return False


class Rectangle:
    """
    Rectangle Class.
    Allows for easy collision checking.

    Warning: collision checking does not work if the Rectangle is not initialized."""

    init = False

    def __init__(self, x1, y1, x2, y2, wh=False):
        """
        Initialization of Rectangle class

        Parameters
        ----------
        x1: :obj:`int`
            First x coordinate of rectangle.
        y1: :obj:`int`
            First y coordinate of rectangle.
        x2: :obj:`int`
            Second x coordinate of rectangle, OR width of rectangle (wh must be True).
        y2: :obj:`int`
            Second y coordinate of rectangle, OR height of rectangle (wh must be True).
        wh: :obj:`bool`
            Whether x2,y2 are coordinates or width and height.
            Set to False if they are coordinates, and True if they are width/height.
        """

        self.init = True
        if wh:
            self.x = x1
            self.y = y1
            self.w = x2
            self.h = y2
            self.width = self.w
            self.height = self.h
        else:
            self.x = (x1, x2)
            self.y = (y1, y2)
            self.x1 = min(self.x)
            self.x2 = max(self.x)
            self.y1 = min(self.y)
            self.y2 = max(self.y)

    def collidePoint(self, x, y):
        """
        Collision checker for Rectangle.
        Checks if an x, y pair collide with the Rectangle.

        WARNING: Rectangle MUST be initiated before checking collision!

        Parameters
        ----------
        x: :obj:`int`
            X coordinate of point to check against Rectangle.
        y: :obj:`int`
            Y coordinate to check against Rectangle.

        Returns
        -------
        True:
            if the point collides with the Rectangle.
        False:
            if the point does not collide with the Rectangle.
        """

        if not self.init:
            raise ReferenceError(
                "Rectangle has not been initiated - cannot check collision."
            )
        if type(self.x) is tuple:
            if self.x1 < x < self.x2 and self.y1 < y < self.y2:
                return True
        else:
            if self.x < x < self.x + self.w and self.y < y < self.y + self.h:
                return True
        return False

    def createLines(self, ax):
        temp = []
        temp.append(
            ax.plot([self.x1, self.x2], [self.y2, self.y2], "k", clip_on=False)[0]
        )
        temp.append(
            ax.plot([self.x1, self.x2], [self.y1, self.y1], "k", clip_on=False)[0]
        )
        temp.append(
            ax.plot([self.x1, self.x1], [self.y1, self.y2], "k", clip_on=False)[0]
        )
        temp.append(
            ax.plot([self.x2, self.x2], [self.y1, self.y2], "k", clip_on=False)[0]
        )
        return temp
