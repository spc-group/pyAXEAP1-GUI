# :author: Alexander Berno

import axeap.core as core
from axeap.core.conventions import X
import sys
import matplotlib
import matplotlib.patches
from functions import *
import multiprocessing
from GetPoints import GetPoints
from axeap.core.roi import HROI
from math import log

multiprocessing.freeze_support()

matplotlib.use("QTAgg")

from PyQt6 import QtCore, QtWidgets, QtGui
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QCheckBox
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg,
    NavigationToolbar2QT as NavigationToolbar,
)
from matplotlib.figure import Figure


# Creates a loading bar window for any loading processes
class LoadingBarWindow(QtWidgets.QProgressDialog):
    def __init__(self, message: str, num: int, *args, **kwargs):
        super(LoadingBarWindow, self).__init__(*args, **kwargs)

        self.setLabelText(message)
        self.setAutoClose(True)
        self.canceled.connect(self.cancel)
        self.setValue(0)
        self.setMaximum(num)

        self.show()

    def add(self):
        self.setValue(self.value() + 1)

    def cancel(self):
        pass


# Creates a window to display errors/problems for users
class ErrorWindow(QtWidgets.QDialog):

    def __init__(self, error: str = "None", *args, **kwargs):
        super(ErrorWindow, self).__init__(*args, **kwargs)

        self.setWindowTitle("Error")
        self.setMinimumHeight(120)
        # error syntax is "[attempted calculation/execution] [reason for not working]"
        if error == "None":
            return
        elif error == "emapCalib":
            labeltext = "You must select calibration data to calculate the energy map."
        elif error == "XESemap":
            labeltext = "You must calculate an energy map to calculate XES spectra."

        button = QtWidgets.QDialogButtonBox.StandardButton.Ok
        label = QtWidgets.QLabel(text=labeltext)
        button_box = QtWidgets.QDialogButtonBox(button)
        button_box.accepted.connect(self.accept)

        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(label)
        layout.addWidget(button_box, alignment=Qt.AlignmentFlag.AlignCenter)

        self.setLayout(layout)
        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()


class MplCanvas(FigureCanvasQTAgg):

    def __init__(
        self,
        parent,
        width=5,
        height=4,
        dpi=100,
    ):
        fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(fig)


class MainWindow(QtWidgets.QMainWindow):
    """Main Window for application. Allows the viewing of data."""

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.sel_x1 = None
        self.sel_y1 = None
        self.sel_x2 = None
        self.sel_y2 = None
        self.sel_ax = None
        self.sel_rect = [None, None, None, None]
        self.rects = []
        self.drawn_calib = False
        self.left_button = False

        self.setWindowTitle("AXEAP Main Window")

        # Canvas and Toolbar for main window
        self.sc = MplCanvas(self, width=5, height=4, dpi=100)
        self.sc.mpl_connect("button_press_event", self.buttonPress)
        self.sc.mpl_connect("button_release_event", self.buttonRelease)
        self.sc.mpl_connect("motion_notify_event", self.pan)
        self.ax = self.sc.figure.add_subplot()
        toolbar = NavigationToolbar(self.sc, self)

        # button for opening calibration data
        cali_button = QtWidgets.QPushButton("Calibration Data...")
        cali_button.clicked.connect(self.openPath)

        # button for calculating energy map
        emap_button = QtWidgets.QPushButton("Calculate Energy Map")
        emap_button.clicked.connect(self.calcEmap)

        # button for opening XES menu
        xes_button = QtWidgets.QPushButton("XES")
        xes_button.clicked.connect(self.runXES)

        # main "widget"; basically everything that is within the main window
        widget = QtWidgets.QWidget()

        # connects everything to the window with grid organization
        self.mlayout = QtWidgets.QGridLayout(widget)
        self.mlayout.addWidget(cali_button, 0, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(emap_button, 1, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(xes_button, 2, 0, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(toolbar, 2, 1, Qt.AlignmentFlag.AlignLeft)
        self.mlayout.addWidget(self.sc, 3, 1, Qt.AlignmentFlag.AlignCenter)
        self.mlayout.setColumnMinimumWidth(0, 240)
        self.mlayout.setColumnMinimumWidth(1, 500)

        self.setCentralWidget(widget)

        self.show()

    def closeEvent(self, event):
        super().closeEvent(event)
        self.deleteLater()

    def openPath(self):
        self.calibfiledir = QtWidgets.QFileDialog.getExistingDirectory()

        if self.calibfiledir is not None and self.calibfiledir != "":
            self.calibscans = loadCalib(self.calibfiledir)
            self.getCalibSpectra()

    def getCalibSpectra(self):

        self.LoadWindow = LoadingBarWindow(
            "Loading calibration data...", len(self.calibscans)
        )
        self.points = []
        self.thread = QtCore.QThread()
        self.worker = GetPoints(scans=self.calibscans)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.finished.connect(self.drawCalibSpectra)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.progress.connect(self.addPoints)

        self.thread.start()

    def addPoints(self, n):
        self.points.append(n)
        self.LoadWindow.add()

    def drawCalibSpectra(self):
        self.ax.cla()
        m = 0

        for i in self.points:
            if m < max(i[2]):
                m = max(i[2])
        for i in self.points:
            alpha = [
                (((0.1 - (0.5 / log(m / 3)) * log(3)) + (0.5 / log(m / 3)) * log(j)))
                for j in i[2]
            ]
            self.ax.scatter(i[0], i[1], s=0.1, color="red", alpha=alpha)

        self.sc.draw()
        self.drawn_calib = True

    def buttonPress(self, event):
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if (
            modifiers == QtCore.Qt.KeyboardModifier.ControlModifier
            or not self.drawn_calib
        ):
            return
        # begins drawing a rectangle over the grid
        if event.button == 1:
            self.left_button = True
            self.sel_ax = event.inaxes
            x = event.xdata
            y = event.ydata
            for j in self.rects:
                i = j[1]
                if i[0] * 0.95 < x < i[0] * 1.05 and i[2] * 0.95 < y < i[2] * 1.05:
                    self.sel_x2 = i[0]
                    self.sel_y2 = i[2]
                    self.sel_x1 = i[1]
                    self.sel_y1 = i[3]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                elif i[1] * 0.95 < x < i[1] * 1.05 and i[2] * 0.95 < y < i[2] * 1.05:
                    self.sel_x2 = i[1]
                    self.sel_y2 = i[2]
                    self.sel_x1 = i[0]
                    self.sel_y1 = i[3]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                elif i[0] * 0.95 < x < i[0] * 1.05 and i[3] * 0.95 < y < i[3] * 1.05:
                    self.sel_x2 = i[0]
                    self.sel_y2 = i[3]
                    self.sel_x1 = i[1]
                    self.sel_y1 = i[2]
                    for i in j[0]:
                        i.remove
                    self.rects.remove(j)
                    break
                elif i[1] * 0.95 < x < i[1] * 1.05 and i[3] * 0.95 < y < i[3] * 1.05:
                    self.sel_x2 = i[1]
                    self.sel_y2 = i[3]
                    self.sel_x1 = i[0]
                    self.sel_y1 = i[2]
                    for i in j[0]:
                        i.remove()
                    self.rects.remove(j)
                    break
                else:
                    continue

            if self.sel_x1 is None and self.sel_y1 is None:
                self.sel_x1 = event.xdata
                self.sel_y1 = event.ydata
            self.sc.draw_idle()
        # deletes a rectangle if the RMB is pressed over a rectangle
        elif event.button == 3:
            for i in self.rects:
                xy = i[1]
                # [0][0][0] and [0][1][0] contain different x values
                # [0][0][1] and [1][0][1] contain different y values
                x1 = min(xy[0], xy[1])
                x2 = max(xy[0], xy[1])
                y1 = min(xy[2], xy[3])
                y2 = max(xy[2], xy[3])
                x = event.xdata
                y = event.ydata
                if x1 < x < x2 and y1 < y < y2:
                    for j in i[0]:
                        j.remove()
                    self.rects.remove(i)
                    break
            self.sc.draw_idle()

    def buttonRelease(self, event):
        if not self.drawn_calib:
            return
        if event.button == 1:
            if not self.left_button:
                return
            self.left_button = False

            if not (self.sel_x1 * 0.9 < self.sel_x2 < self.sel_x1 * 1.1) or not (
                self.sel_y1 * 0.9 < self.sel_y2 < self.sel_y1 * 1.1
            ):
                rect = [None, None, None, None]
                # lines drawn x1y1 to x2y1, x2y1 to x2y2, x2y2 to x1y2, x1y2 to x1y1
                (rect[0],) = self.sel_ax.plot(
                    [self.sel_x1, self.sel_x2],
                    [self.sel_y1, self.sel_y1],
                    clip_on=False,
                    color="red",
                )
                (rect[1],) = self.sel_ax.plot(
                    [self.sel_x2, self.sel_x2],
                    [self.sel_y1, self.sel_y2],
                    clip_on=False,
                    color="red",
                )
                (rect[2],) = self.sel_ax.plot(
                    [self.sel_x2, self.sel_x1],
                    [self.sel_y2, self.sel_y2],
                    clip_on=False,
                    color="red",
                )
                (rect[3],) = self.sel_ax.plot(
                    [self.sel_x1, self.sel_x1],
                    [self.sel_y2, self.sel_y1],
                    clip_on=False,
                    color="red",
                )
                rect = [
                    rect.copy(),
                    (self.sel_x1, self.sel_x2, self.sel_y1, self.sel_y2),
                ]
                self.rects.append(rect)

            try:
                if self.sel_rect[0] is not None:
                    self.sel_rect[0].remove()
                if self.sel_rect[1] is not None:
                    self.sel_rect[1].remove()
                if self.sel_rect[2] is not None:
                    self.sel_rect[2].remove()
                if self.sel_rect[3] is not None:
                    self.sel_rect[3].remove()
            finally:
                self.sel_rect = [None, None, None, None]
            self.sel_x1 = None
            self.sel_y1 = None
            self.sel_ax = None
            self.sc.draw()

    def pan(self, event):
        if not self.drawn_calib:
            return
        if self.sel_x1 is not None and self.sel_y1 is not None:
            x = event.xdata
            y = event.ydata
            if x is None or y is None:
                return
            self.sel_x2 = x
            self.sel_y2 = y
            try:
                if self.sel_rect[0] is not None:
                    self.sel_rect[0].remove()
                if self.sel_rect[1] is not None:
                    self.sel_rect[1].remove()
                if self.sel_rect[2] is not None:
                    self.sel_rect[2].remove()
                if self.sel_rect[3] is not None:
                    self.sel_rect[3].remove()
            finally:
                self.sel_rect = [None, None, None, None]
            (self.sel_rect[0],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x2],
                [self.sel_y2, self.sel_y2],
                "k",
                clip_on=False,
            )
            (self.sel_rect[1],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x2],
                [self.sel_y1, self.sel_y1],
                "k",
                clip_on=False,
            )
            (self.sel_rect[2],) = self.sel_ax.plot(
                [self.sel_x1, self.sel_x1],
                [self.sel_y1, self.sel_y2],
                "k",
                clip_on=False,
            )
            (self.sel_rect[3],) = self.sel_ax.plot(
                [self.sel_x2, self.sel_x2],
                [self.sel_y1, self.sel_y2],
                "k",
                clip_on=False,
            )
            self.sc.draw_idle()

    # temp class for calculating horizontal regions of interest
    def calcHrois(self):
        # this section calculates the hrois
        # s = self.calibscans.items[0]
        self.hrois = []
        for i in self.rects:
            self.hrois.append(HROI(i[1][0], i[1][1]))
        # min_width = s.dims[X] / numcrystals / 3
        # self.hrois = core.calcHROIs(
        #     s.mod(cuts=(3, 10)), min_width=min_width, group_buffer=10
        # )
        # print("done")

    def calcEmap(self):
        try:
            scans = self.calibscans
        except:
            self.error = ErrorWindow("emapCalib")
        else:
            self.calcHrois()
            self.emap = core.calcEMap(scans, self.hrois)

    def runXES(self):
        self.childWindow = self.XESWindow(self)

    class XESWindow(QtWidgets.QMainWindow):
        """Window for viewing XES spectra"""

        def __init__(self, parent: QtWidgets.QMainWindow, *args, **kwargs):
            super(MainWindow.XESWindow, self).__init__(*args, **kwargs)

            # sets the main window as the parent
            self.parent = parent
            self.setWindowTitle("XES Window")

            # canvas for XES spectra and XES button for opening XES files
            self.sc = MplCanvas(self, width=5, height=4, dpi=100)
            self.ax = self.sc.figure.add_subplot()
            toolbar = NavigationToolbar(self.sc, self)
            self.xes_button = QtWidgets.QPushButton("XES Data...")
            self.xes_button.clicked.connect(self.loadXES)

            # connects everything to the XES window
            widget = QtWidgets.QWidget()
            self.mlayout = QtWidgets.QGridLayout(widget)
            self.mlayout.addWidget(toolbar, 1, 1, Qt.AlignmentFlag.AlignLeft)
            self.mlayout.addWidget(self.sc, 2, 1, Qt.AlignmentFlag.AlignCenter)
            self.mlayout.addWidget(self.xes_button, 0, 0, Qt.AlignmentFlag.AlignCenter)
            self.mlayout.setColumnMinimumWidth(0, 240)
            self.mlayout.setColumnMinimumWidth(1, 500)

            self.setCentralWidget(widget)

            self.show()

        def closeEvent(self, event):
            super().closeEvent(event)
            self.deleteLater()

        # loads XES data (currently only able to load from TIF files)
        def loadXES(self):
            try:
                self.parent.emap
            except:
                self.error = ErrorWindow("XESemap")
                return

            self.filenames = QtWidgets.QFileDialog.getOpenFileNames(
                filter="TIF Files (*.tif *.tiff)"
            )
            if self.filenames is None or len(self.filenames[0]) == 0:
                return
            self.checks = QtWidgets.QScrollArea()
            self.checks.setMinimumWidth(240)
            self.check_widgets = QtWidgets.QWidget()
            self.checks_grid = QtWidgets.QGridLayout(self.check_widgets)

            emap = self.parent.emap
            # plots all XES spectra with 100Y spacing between them.
            LoadWindow = LoadingBarWindow("Loading XES data...", len(self.filenames[0]))
            scanset = []
            for i in self.filenames[0]:
                scanset.append(calcXESSpectra(i, emap))
                LoadWindow.add()
                QtWidgets.QApplication.processEvents()
            LoadWindow.deleteLater()
            self.spectra = [
                self.Spectrum(self, scanset[i], i + 3) for i, _ in enumerate(scanset)
            ]

            self.disp_spectra = self.spectra.copy()

            all_button = QtWidgets.QPushButton()
            all_button.clicked.connect(self.allSpectra)
            all_button.setText("All")
            none_button = QtWidgets.QPushButton()
            none_button.clicked.connect(self.noSpectra)
            none_button.setText("None")
            invert_button = QtWidgets.QPushButton()
            invert_button.clicked.connect(self.invertSpectra)
            invert_button.setText("Invert")
            self.checks_grid.addWidget(all_button, 0, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks_grid.addWidget(none_button, 1, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks_grid.addWidget(invert_button, 2, 0, Qt.AlignmentFlag.AlignLeft)
            self.checks.setWidget(self.check_widgets)
            self.mlayout.addWidget(self.checks, 2, 0, Qt.AlignmentFlag.AlignCenter)

            self.stackSpectra()
            self.graphSpectra()

        def allSpectra(self):
            for i in self.spectra:
                i.box.setChecked(True)

        def noSpectra(self):
            for i in self.spectra:
                i.box.setChecked(False)

        def invertSpectra(self):
            for i in self.spectra:
                if i in self.disp_spectra:
                    i.box.setChecked(False)
                else:
                    i.box.setChecked(True)

        def stackSpectra(self):
            length = len(self.disp_spectra)
            for i in self.disp_spectra:
                i.current = i.base.copy()
                for j, _ in enumerate(i.base):
                    inc = 100 * length
                    i.increaseIntensity(inc, j)
                length -= 1

        def graphSpectra(self):
            self.ax.cla()
            for i in self.disp_spectra:
                self.ax.plot(i.energies, i.current)
            self.sc.draw()

        def removeSpectrum(self, spectrum):
            self.disp_spectra.pop(self.disp_spectra.index(spectrum))
            self.stackSpectra()
            self.graphSpectra()

        def addSpectrum(self, spectrum):
            num = self.spectra.index(spectrum)
            count = 0
            for i in range(num):
                if self.spectra[i] in self.disp_spectra:
                    count += 1
            self.disp_spectra.insert(count, spectrum)
            self.stackSpectra()
            self.graphSpectra()

        class Spectrum:
            def __init__(self, parent, spectrum, num):
                self.parent = parent
                self.energies = spectrum.energies
                self.base = spectrum.intensities.copy()
                self.current = self.base.copy()
                t = self.parent.filenames[0][num - 3]
                self.name = t[t.rfind("/") + 1 :]
                self.box = QCheckBox()
                self.box.setChecked(True)
                self.box.stateChanged.connect(self.hide)
                self.box.setText(self.name)

                self.parent.checks_grid.addWidget(
                    self.box, num, 0, Qt.AlignmentFlag.AlignLeft
                )

            def increaseIntensity(self, inc, pos):
                self.current[pos] += inc

            def hide(self, s):
                if s != Qt.CheckState.Checked.value:
                    self.parent.removeSpectrum(self)
                else:
                    self.parent.addSpectrum(self)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setWindowIcon(QtGui.QIcon("spc-logo-nobg.png"))
    W = MainWindow()
    # sys.exit(app.exec())
    app.exec()
