from PyQt6 import QtWidgets
from PyQt6 import QtCore

AlignFlag = QtCore.Qt.AlignmentFlag


class CalibFile:
    def __init__(self, parent, name, row):
        self.name = name
        self.parent = parent

        self.label = QtWidgets.QLabel(self.name[self.name.rfind("/") + 1 :])
        self.val = QtWidgets.QDoubleSpinBox()
        self.val.setMaximum(1000000)
        self.val.setDecimals(4)
        self.val.setMinimumWidth(160)
        self.parent.calib_grid.addWidget(self.label, row, 0, AlignFlag.AlignLeft)
        self.parent.calib_grid.addWidget(self.val, row, 1, AlignFlag.AlignLeft)

    def changeVal(self, val):
        self.val.setValue(val)

    def getVal(self):
        return self.val.value()
