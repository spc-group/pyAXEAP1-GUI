from PyQt6 import QtWidgets, QtCore

AlignFlag = QtCore.Qt.AlignmentFlag


class Spectrum:
    """Spectrum class. Used to store all data related to each spectra."""

    def __init__(self, parent, spectrum, colour, num):
        self.restack_now = True
        self.parent = parent
        self.energies = spectrum.energies
        self.intensities = spectrum.intensities
        self.spectrum = spectrum

        self.base = spectrum.intensities.copy()
        self.current = self.base.copy()

        self.colour = colour

        t = self.parent.filenames[0][num - 3]
        self.name = t[t.rfind("/") + 1 :]
        self.box = QtWidgets.QCheckBox()
        self.box.setChecked(True)
        self.box.stateChanged.connect(self.hide)
        self.box.setText(self.name + ", " + str(tuple(int(i) for i in colour)))

        self.parent.checks_grid.addWidget(self.box, num, 0, 1, 3, AlignFlag.AlignLeft)

    def increaseIntensity(self, inc, pos):
        self.current[pos] += inc

    def hide(self, s):
        if s != QtCore.Qt.CheckState.Checked.value:
            self.parent.removeSpectrum(self)
        else:
            self.parent.addSpectrum(self)
